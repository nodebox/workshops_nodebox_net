# This is a more advanced version for the "pixelfontcreator", an idea tool 
# to assist you in the creation of pixel fonts. It has lots of variables 
# that show up in the variable panel:
# >>>
#   "Ypixels": Defines the number of vertical boxes in the "pixel" grid
#   "Xpixels": Defines the number of horizontal boxes in the "pixel" grid
#   "Letter": Defines the letter (or the text) overlayed on top of the "pixel grid"
#   "Font": Defines which is the font of the overlayed text. This has to be the
#           postscript name of the font:
#           Font Book > Preview > Show Font Info > PostScript name
#   "show_letter": When ticked, shows the overlayed text.
#   "tick_to_generate": Just a dummy ticking box. Included here so that you don't 
#                       have to press command+R all the time.
#   "Letter_size": Changes the size of the overlayed text.
#   "baseline_shift": Moves the baseline of the overlayed text.
#   "Background": Background color. ON/OFF.

r1 = 0
g1 = 0
b1 = 0.5

r2 = 1
g2 = 1
b2 = 1

var("Xpixels", TEXT, 3, 1, 10)
var("Ypixels", TEXT, 3, 1, 10)
var("Letter", TEXT, "a")
var("Font", TEXT, "Garamond")
var("show_letter", BOOLEAN, False)
var("tick_to_generate", BOOLEAN, False)
var("Letter_size", NUMBER, 70, 70, 300)
var("baseline_shift", NUMBER, 0, -30, 300)
var("Background", BOOLEAN, True)

if Background == True:
    background(r1,g1,b1)

Xpixels = int(Xpixels)
Ypixels = int(Ypixels)

w = 70
h = 70

white = color(1)
black = color(0)

for x, y in grid(Xpixels, Ypixels, w, h):
        
    #fill(0,0,0,random())
    #fill( choice((white,black)) )
    gridcolor = color(0, 0, 0)
    c = choice((gridcolor, white))
    fill(c)
    rect(x, y, w, h)
            
    #canvas = coreimage.canvas(w,h)
    #l = canvas.layer_radial_gradient(c)
    #canvas.draw(x, y)

    #fill(1,0,0, 0.5)
    #fontsize(h)
    #lineheight(1)
    #align(CENTER)
    #text(letter, x, y+fontsize(), width=w)
    
font(Font)
fill(0.4,0.3,0.3, 0.5)
fontsize(Letter_size*Ypixels+30)
lineheight(1)
align(CENTER)

if show_letter == True:
    text(Letter, 0, h*Ypixels+baseline_shift, width=w*Xpixels)