# Tää määrittelee taustavärin >>
#taustaväri esim.:
#background(R, G, B, Aplha)

background(0.50, 0.90, 0.88, 0.80)

# Seuraavaksi tulisi gridin muodon säätövivut (joita ei oo) >>

#var("ypixels", NUMBER, 3, 1, 10)
#var("xpixels", NUMBER, 3, 1, 10)


# Tässä on rivisäätöjen tekstikentät >>

var("ypixels", TEXT, 3, 1, 10)
var("xpixels", TEXT, 3, 1, 10)
xpixels = int(xpixels)
ypixels = int(ypixels)

# Tässä on variablella tehty säätövipu joka on mukana vaan näon vuoks
# + siks ettei tarvi joka kerta painaa omppu R >>

var("generator", NUMBER, 3, 1, 10)

# Tässä olis fiksattu pixelifontin gridi >>

#ypixels = 4
#xpixels = 4

# Nää variablet määrittää pixelien koot pisteissä >>

w = 70
h = 70

# Nää taas värit >>

white = color(1)
black = color(0)

# Tässä on eka luuppi, joka määrittelee kuinka monta pikseligridiä ilmestyy >>
# (i meinaa laskuria luupille )
# ELI ELI ELI siis toi for i in range() meinaa että se toistaa sen sisällä olevan koodin (x) kertaa >>
for i in range(3):
    # Tää käsky näyttää laskurin arvon ala-oikeella olevassa ruudussa, 
    # Tässä tapauksessa se liittyy piksekigridin numeroon (0=1.gridi,1=2.gridi... >>
    print i
    # Tässä on variable "gridwidth" joka määrittää 1. gridin kokonaisleveyden >>
    gridwidth = w*xpixels + 30
    print gridwidth
    
    # Tää ensimmäinen gridi on siis koko se pohja, jolla nämä pixeligridit makaa
    # Tämä kyseinen pohja on näkymätön.
    
    # Nyt tulee uusi luuppi, joka koskee pikseligridejä näkymättömän gridin sisällä.

    for x, y in grid(xpixels, ypixels, w, h):
    
        #fill(0,0,0,random())
        #fill( choice((white,black)) )
        gridcolor = color(i*0.3, 0, 0)
        # Tää seuraava on ehkä tärkein pikseligeneraattorissa. "choice" -käsky
        # valitsee, onko ruudukon jonkun kohdan väri variable "gridcolor" vai valkone
        fill( choice((gridcolor, white)) )
        rect(x + gridwidth*i, y, w, h)