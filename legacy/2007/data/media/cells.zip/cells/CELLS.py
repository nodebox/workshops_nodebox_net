supershape = ximport("supershape")

# The parameters for a supershape:
# a location defined by x (horizontal) and y (vertical),
# a size defined by w (width) and h (height),
# an m parameter that controls the number of spikes,
# and three n transformations.
x = 250
y = 250
w = 100
h = 100
m = 12
n1 = -1.0
n2 = 0.5
n3 = 0.5

# This commeand returns a vector path based on a supershape.
# We can pass a v parameter to it that modifies the
# supershape parameters.
def shape1(v):
    return supershape.path(x, y, w, h, m+v*2, n1-v/2, n2*v, n3)

def shape2(v):
    return supershape.path(x, y, w, h, m-v*8, n1*v, n2, n3)

def shape3(v):
    return supershape.path(x, y, w-v*10, h-v*10, m+0.5, n1, n2-v/20, n3+100)

def shape4(v):
    #font("Georgia", 150)
    font("Georgia", 30*v)
    # This shape is based on a path constructed from text.
    p = textpath("O", x, y)
    # Transformt the path with a superformula.
    return supershape.transform(p, 6, 0.2, 0.5, 140, points=100)

# Light cyan background.
fill(0.8, 1.0, 1.0)
rect(0, 0, WIDTH, HEIGHT)

# Do the next commands ten times
for i in range(10):
    
    # Fill and stroke color.
    # The values range between 0.0 and 1.0,
    # defining the percentage (0-100%) of R, G, B and Alpha.
    fill(0, i*0.1, 1.0, 0.1)
    stroke(0, 0.5, 1.0, 0.3)
    strokewidth(1.0)
    
    # Rotate the next shape by 36 degrees.
    rotate(36)
    p = shape1(i)
    #p = shape2(i) # Try different shapes!
    #p = shape3(i) # Change the numbers in the script for different effects!
    #p = shape4(i)
    drawpath(p)
        
        
