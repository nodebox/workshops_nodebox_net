size(900, 800)
speed(10)

coreimage = ximport("coreimage")
reload(coreimage)
coreimage.PATH_PADDING = 10

def setup():
    
    global cache
    cache = None
    

def draw():
    
    c = coreimage.canvas(WIDTH, HEIGHT)
    font("Smoke sans")
    fontsize(80)
    p = textpath("SMOKE SANS!", 0, 0)
    l = c.layer_path(p)
    
    global cache
    if cache:
        cache = c.layer(cache)
    else:
        p = textpath("thursday", 0, 0)
        cache = c.layer_path(p)
    
    cache.filter_bumpdistortion(scale=-1.0, radius=10, 
                                dx=random(100,300), 
                                dy=random(20,100))
  
    cache.filter_twirl(dx=random(200,200),
                       dy=random(50,100), 
                       angle=random(300,300), 
                       radius=10)
    
    cache.filter_holedistortion(dx=random(-200,200),
                                dy=random(-50,300),
                                radius=40)
    
    cache.blend(90)
    
    cache = c.render()
    c.draw()