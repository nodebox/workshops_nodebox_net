import time
from AppKit import *
speed(100)

scrape = NSSound.alloc().initWithContentsOfFile_byReference_("scrape.wav", True)
click = NSSound.alloc().initWithContentsOfFile_byReference_("click.wav", True)
can = NSSound.alloc().initWithContentsOfFile_byReference_("can.wav", True)
pickup = NSSound.alloc().initWithContentsOfFile_byReference_("pickup.wav", True)
chop = NSSound.alloc().initWithContentsOfFile_byReference_("chop.wav", True)

key_map = {'q':scrape, 'w':click, 'e':can, 'r':pickup, 't':chop}

def draw():
    global playing
    
    if keydown:
        sound = key_map.get(key)
        if sound is not None:
            sound.stop()
            sound.play()
        
    for i, (k, sound) in enumerate(key_map.items()):
        if sound.isPlaying():
            xpos = i
            text(k, 20 + xpos*20, 30)
            