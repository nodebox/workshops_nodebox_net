class Point:
    
    def __init__(self, x, y):
        
        self.x = x
        self.y = y

class Sight:
    
    def __init__(self, a=90, r=100):
        
        self.angle = a
        self.range = r

class Creature:
    
    def __init__(self, x, y):
        
        self.x = x
        self.y = y
        
        self.v = 0.1
        self.vx = random(-3.0, 3.0)
        self.vy = random(-3.0, 3.0)
        
        self.has_goal = False
        self.gx = None
        self.gy = None
        self.gd = 0.2
        
        self.obstacles = []

        self.sight = Sight()

        self.trail = []
      
    def angle_to(self, x, y):
        
        from math import atan, pi, degrees  
        a = degrees( atan((y-self.y) / (x-self.x+0.00001)) ) + 360
        if x-self.x < 0: a += 180
        return 360 - a

    def bearing(self):
        
        from math import atan, pi, degrees
        a = degrees(atan(self.vy/self.vx)) + 360
        if self.vx < 0: a += 180
        return 360 - a
        
    def distance_from(self, x, y):
    
        from math import sqrt, pow
        return sqrt(pow(x-self.x, 2) + pow(y-self.y, 2))
        
    def can_see(self, x, y):
        
        d = self.distance_from(x, y)
        a = self.angle_to(x, y)
        b = self.bearing()

        stroke(0)
        push()
        transform(CORNER)
        translate(self.x, self.y)
        rotate(a)
        line(0,0,50,0)
        pop()

        stroke(0)
        push()
        transform(CORNER)
        translate(self.x, self.y)
        rotate(b)
        line(0,0,10,0)
        pop()

        #print d
        if d < self.sight.range \
        and b%360-self.sight.angle/2 < a%360 < b%360+self.sight.angle/2:
        #and abs(a-b)%360 < self.sight_angle:
            return True
        else:
            return False

    def goal(self, x, y):
        
        self.has_goal = True
        self.gx = x
        self.gy = y
    
    def no_goal(self):
        
        self.has_goal = False
        self.gx = None
        self.gy = None
    
    def obstacle(self, x, y):
        
        self.obstacles.append(x, y)
    
    def cage(self, x, y, w, h):
        
        dx = - w * 0.2
        dy = - h * 0.2 
        
        if self.x < x-dx: 
            self.vx += random(self.v)
        if self.y < y-dy: 
            self.vy += random(self.v)
        if self.x > x+w+dx: 
            self.vx -= random(self.v)
        if self.y > y+h+dy: 
            self.vy -= random(self.v)

    def roam(self):
        
        self.vx += random(-self.v, self.v)
        self.vy += random(-self.v, self.v)
        
        if self.has_goal:
            self.vx += (self.gx-self.x) * random(self.v * self.gd)
            self.vy += (self.gy-self.y) * random(self.v * self.gd)
        
        limit = self.v * 1000
        if abs(self.vx) > limit: 
            self.vx = self.vx/abs(self.vx)*limit
        if abs(self.vy) > limit: 
            self.vy = self.vy/abs(self.vy)*limit
        
        self.x += self.vx
        self.y += self.vy
        
        self.trail.append(Point(self.x, self.y))
        if len(self.trail) > 10:
            del self.trail[0]


size(400, 400)
speed(100)

def setup():
    
    global creatures
    creatures = []
    for i in range(2):
        c = Creature(random(WIDTH), random(HEIGHT))
        creatures.append(c)
    #creature.goal(100, 100)

def draw():
    
    global creatures
    for c in creatures:
        c.cage(0, 0, WIDTH, HEIGHT)
        c.roam()
    
        r = 4
        oval(c.x-r/2, c.y-r/2, r, r)
    
        
        a = c.bearing()
        strokewidth(0.5)
        stroke(0)
        transform(CORNER)
        push()
        translate(c.x, c.y)
        rotate(a+c.sight.angle/2)
        line(0, 0, c.sight.range, 0)
        pop()
        push()
        translate(c.x, c.y)
        rotate(a-c.sight.angle/2)
        line(0, 0, c.sight.range, 0)
        pop()
    
        other = creatures[creatures.index(c)-1]
        
        if c.can_see(other.x, other.y):
            c.goal(other.x, other.y)
        if c.has_goal:
            c.goal(other.x, other.y)
        
        reset()
        x0 = c.trail[0].x
        y0 = c.trail[0].y
        for p in c.trail:
            r = 4
            oval(p.x-r/2, p.y-r/2, r, r)
            line(p.x, p.y, x0, y0)
            x0 = p.x
            y0 = p.y