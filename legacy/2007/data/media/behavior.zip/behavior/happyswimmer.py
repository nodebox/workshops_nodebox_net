speed(200)
size(400,400)

from math import sin, cos, radians

class Oscillator:
    
    def __init__(self, g=1, bounce=True):
        
        self.g = g
        self.bounce = bounce
        self.angle = 0
        if not self.bounce: self.angle = -90
        self.time = 0
        
    def update(self):
        
        self.angle += self.g
        m = 180
        if not self.bounce: m = 360
        if self.angle >= m: self.angle = 0
        self.time = sin(radians(self.angle))
        if not self.bounce: self.time = (self.time+1)/2
        

class Paddle:
    
    def __init__(self, body, left, right):
        
        self.o = Oscillator()
        self.body = body
        self.left = left
        self.right = right
        
    def update(self):
        
        self.o.update()
        
        

def setup():
    
    global o1, o2, x, y, r
    o1 = Oscillator(g=4, bounce=False)
    o2 = Oscillator(g=4, bounce=False)
    x = 200
    y = 200
    r = 50
    
def draw():
    
    global o1, o2, x, y, r
    o1.update()
    o2.update()
    
    r += 1
    
    vx = sin(radians(r))
    vy = cos(radians(r))
    y -= vy * abs(o2.time*2+0.4)
    x -= vx * abs(o2.time*2+0.4)
    
    oval(x-5, y-5, 10, 10)
    
    stroke(0)
    
    translate(x, y)
    transform(CORNER)
    push()
    rotate(r+45-90*o1.time)
    l = 50
    d = (1 - o2.time) * (l/2)
    line(0, 0, l-d, 0)
    oval(l-d-10, 0-10, 20, 20)
    pop()

    push()
    rotate(r-45+90*o1.time)  
    line(0, 0, -l+d, 0) 
    oval(-l+d-10, 0-10, 20, 20)
    pop()

    
    push()
    rotate(r+45-110*o1.time*1.2)
    l = 50
    d = (1 - o2.time*2.5) * (l/2)
    line(0, 0, l-d, 0)
    oval(l-d-5, 0-5, 10, 10)
    pop()
        
    push()
    rotate(r-45+110*o1.time*1.1)  
    line(0, 0, -l+d, 0) 
    oval(-l+d-5, 0-5, 10, 10)
    pop()
    