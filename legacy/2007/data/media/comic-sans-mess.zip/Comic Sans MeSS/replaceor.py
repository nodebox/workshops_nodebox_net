buzzwords = ["t", "contextual replacement"]

replacements = {' ':'space', '-':'dash', '.':'period',}


print "feature liga {"
for word in buzzwords:
    
    new_word = []
    for c in word:
        new_word.append(replacements.get(c, c))
    # print new_word
    
    for i, c in enumerate(new_word):
        print "    sub ",
        for prev_c in new_word[:i]:
            print prev_c + ".cs ",
            
        print c + "' ",
            
        for next_c in new_word[i+1:]:
            print next_c + " ",
        print "by %s.cs;" % c
    print
print "} liga;"