# Speech recognition in NodeBox.
# Note that the speech recognizer in Mac OS X is not exactly known for its acurateness,
# so this is more of a humurous script than something really useful.

# Run the script, wait for the speech box to come up, 
# then hold the <escape> key and say something!

size(500, 500)
from Foundation import NSObject
from AppKit import NSSpeechRecognizer
import time
from math import sin, cos

speed(30)

def setup():
    # Get a cached speech recognizer
    try:
        speech = __doc__['speech']
    except KeyError:
        speech = None
    if speech is None:
        speech = __doc__['speech'] = NSSpeechRecognizer.alloc().init()

    # Open the list of common words and use it as the commands file.
    # You can look at the list of commands the system can recognize
    # by pressing the gray arrow at the bottom of the recognizer widget
    # and selecting "Open Speech Command Window"
    lines = open('common.txt').readlines()
    lines = [line.strip() for line in lines]
    speech.setCommands_(lines)
    speech.setBlocksOtherRecognizers_(True)

    # The speech recognizer uses a delegate that gets called when a command is recognized.
    # The delegate is called asynchrously.
    rd = RecognizerDelegate.alloc().init()
    speech.setDelegate_(rd)
    speech.setListensInForegroundOnly_(False)
    speech.startListening()
    
def draw():
    background(0.9, 0.7, 0.2)
    fill(0.3, 0, 0)
    font("LucidaGrande-Bold", 12)
    text("Hold the <escape> key, then say something!", 10, HEIGHT - 12)
    commands = __doc__['speech'].delegate().commands
    i = j = 0.0
    # Draw all recognized commands
    for c in commands:
      text(c, sin(FRAME/30.0+i) * 200.0 + 200, cos(FRAME/30.0+j) * 200.0 + 250)
      i += 0.05
      j -= 0.09    
    
class RecognizerDelegate(NSObject):
    def init(self):
        self = super(RecognizerDelegate, self).init()
        self.commands = []
        return self
        
    def speechRecognizer_didRecognizeCommand_(self, recognizer, command):
        self.commands.append(command)
