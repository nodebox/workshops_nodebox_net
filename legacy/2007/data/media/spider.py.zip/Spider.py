# Connects parts of letters together

size(600, 207)
background(0.1,0,0.2)

from math import sqrt, pow

fontsize(150)
path = textpath("SPIDER",20, 150)

def calc_length(x1, y1, x2, y2):
    return sqrt(pow(x2-x1, 2) + pow(y2-y1, 2))

nofill()
stroke(1)
strokewidth(0.3)

d = 2.0
for contour in path.contours:
    path_points = list(contour.points(100))
    for i in range(300):
        pt1 = choice(path_points)
        length = float("inf")
        while length > 40.0:
            pt2  =choice(path_points) 
            length = calc_length(pt1.x, pt1.y, pt2.x, pt2.y)
        line(pt1.x+random(-d, d), pt1.y+random(-d, d), pt2.x+random(-d, d), pt2.y+random(-d, d))