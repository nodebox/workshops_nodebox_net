### CREDITS ##########################################################################################

__author__    = "Tom De Smedt"
__version__   = "1.8.2"
__copyright__ = "Copyright (c) 2006 Tom De Smedt"
__license__   = "MIT"

### NODEBOX CORE IMAGE ###############################################################################

# The Core Image library for NodeBox adds image manipulation to NodeBox.
# It's like having control over Photoshop through simple Python programming commands.
# Core Image is a Mac OS X specific framework available from Mac OS X 1.4 (Tiger).

# The library depends on the Cocoa ObjC AppKit and Foundation modules (bundled with NodeBox),
# the Python math module, the Python Numeric module (bundled with NodeBox) for pixel operations,
# the Python Core Graphics module (installed on the Mac by default) for CMYK conversion,
# the NodeBox DrawingPrimitives module for drawing operations in NodeBox.
# However, all of the classes are loosely connected so it probably isn't that much work
# to make the library work in a different environment.
# Different renderers can also "easily" be implemented, for example in PIL.

# The library is currently in alpha stage and has some known issues and limitations:
# - exporting a canvas with a transparent background as PDF might have pixel errors
# - exporting a CMYK TIFF uses a Generic CMYK profile which makes no attempt at color correction
# - layer distortion in combination with layer filters displaces the layer from the origin,
#   because the bounding box of a layer does not take filters into account. 
#   An easy way to overcome this is to call layer.filters_first(False) to first render
#   the distort and then apply the filter.
# - combining different filters might produce no output or crash NodeBox
# - the Motion Blur filter is especially quirky

### CONSTANTS ########################################################################################

LAYER_FILE            = "file"
LAYER_FILL            = "fill"
LAYER_RADIAL_GRADIENT = "radial"
LAYER_LINEAR_GRADIENT = "linear"
LAYER_LAYERS          = "layers"
LAYER_PATH            = "path"
LAYER_CIIMAGEOBJECT   = "CIImageobject"

ARRANGE_UP        = "up"
ARRANGE_DOWN      = "down"
ARRANGE_FRONT     = "front"
ARRANGE_BACK      = "back"

ORIGIN_LEFT       = "left"
ORIGIN_TOP        = "top"
ORIGIN_BOTTOM     = "bottom"
ORIGIN_RIGHT      = "right"
ORIGIN_CENTER     = "center"

FLIP_HORIZONTAL   = "horizontal"
FLIP_VERTICAL     = "vertical"

BLEND_NORMAL      = "normal"
BLEND_MULTIPLY    = "multiply"
BLEND_SCREEN      = "screen"
BLEND_OVERLAY     = "overlay"
BLEND_SOFTLIGHT   = "softlight"
BLEND_HARDLIGHT   = "hardlight"
BLEND_HUE         = "hue"
BLEND_COLOR       = "color"

FILE_GIF          = "GIF"
FILE_PNG          = "PNG"
FILE_JPEG         = "JPEG"
FILE_TIFF         = "TIFF"

# Controls how much extra space to leave between
# the actual path and its bounding box.
PATH_PADDING = 0

### EXCEPTIONS #######################################################################################

class CanvasToNodeBoxError: pass

class CanvasInCanvasRecursionError: pass

### POINT ############################################################################################

class Point:
    
    def __init__(self, x, y):
        
        self.x = x
        self.y = y

### COLOR ############################################################################################

class Color:
    
    def __init__(self, r, g=None, b=None, a=None):
        
        """ Stores channel values for a color.
        
        If one value is given and it is a Color object, copy that.
        If one value is given, create a grayscale color.
        If two values are given, create a grayscale color with alpha.
        If three values are given, create an opaque color.
        
        """

        try: 
            is_nodebox_color = isinstance(data, _ctx.Color().__class__)
        except: 
            is_nodebox_color = False
        
        if isinstance(r, Color) or is_nodebox_color:
            # One parameter, a Color object.
            r, g, b, a = r.r, r.g, r.b, r.a
        if a == None:
            # No alpha means an opaque color.
            a = 1.0
        if g == None and b == None:
            # One parameter, a grayscale value.
            g, b = r, r
        if b == None:
            # Two parameters, gray value and alpha.
            a, g, b = g, r, r
        
        if isinstance(r, int): r = float(r) / 255
        if isinstance(g, int): g = float(g) / 255
        if isinstance(b, int): b = float(b) / 255
        if isinstance(a, int): a = float(a) / 255
        
        self.r = max(0.0, min(r, 1.0))
        self.g = max(0.0, min(g, 1.0))
        self.b = max(0.0, min(b, 1.0))
        self.a = max(0.0, min(a, 1.0))
        
    def __repr__(self):
        
        return "%s(%s, %s, %s, %s)" % (self.__class__.__name__, 
                self.r, self.g, self.b, self.a)

### TRANSPARENT ######################################################################################
  
class Transparent(Color):
    
    def __init__(self):
        
        Color.__init__(self, 0.0, 0.0, 0.0, 0.0)

### PATH #############################################################################################

class Path:
    
    def __init__(self, path):
        
        """ A wrapper for acceptable bezier paths.
        
        Transforms a given path to an NSBezierPath.
        Acceptable path parameters are currently:
        1) a NodeBox BezierPath which is the handiest format
        2) a list of points forming a polygon
        3) an NSBezierPath.
        
        """
        
        self.path = None
        
        try:
            b = isinstance(path, _ctx.BezierPath().__class__)
            if b: self.path = path.path
        except:
            pass
    
        if isinstance(path, list):
            p = NSBezierPath.bezierPath()
            first = True
            for i in range(len(path)/2):
                x = path[i*2]
                y = path[i*2+1]
                if first == True:
                    p.moveToPoint_((x, y))
                    first = False
                else:
                    p.lineToPoint_((x, y))
            self.path = p
            
        if isinstance(path, NSBezierPath):
            self.path = path
    
    def is_path(self):
        
        return (self.path != None)

### CANVAS ###########################################################################################
        
class Canvas:
    
    def __init__(self, w, h, renderer):
        
        self.renderer = renderer
        self.layers = Layers()
        self._parent = None
        self.w = w
        self.h = h
    
    def copy(self):
        
        canvas = Canvas(self.w, self.h, self.renderer)
        canvas._parent = self._parent
        for layer in self.layers:
            canvas.layers.append(layer.copy())
        
        return canvas
    
    def layer(self, data, type=None, x=None, y=None, w=None, h=None, name="", **kwargs):
        
        """
        
        Adds a new layer to the canvas.
        
        A new layer can be created from the following data:
        1) string: the path to an image on disk (.jpg, .png, .tif),
        2) Color: an opaque color layer,
        3) (Color, Color): a linair gradient,
        4) (Color, Color) combined with spread parameter: a radial gradient,
        5) Canvas: a composite layer group based on other layers,
        6) (Path, Color, Color): a layer based on a vector drawing.
        
        When a width or height is given for an image file,
        the layer will store the original image's width and height
        and adjust its scaling.
        
        By default, layers are placed at the center of the canvas.
        Paths that have an x and y origin different from zero
        are translated from the given x and y parameters.
        
        Layers have a default width and height equal to the canvas,
        except when given or the source image file has other dimensions.
                
        Always use Canvas.layer() to create new layers as this method
        initializes all the layer attributes in the correct way.
        
        """

        def _add_layer(data, type, x=None, y=None, w=None, h=None, s=Point(1.0,1.0)):
            if x == None: x = self.w/2
            if y == None: y = self.h/2
            if w == None: w = self.w
            if h == None: h = self.h
            layer = Layer(self, type, data, x, y, w, h, name)
            layer._scale = s
            self.layers.append(layer)
            return layer          
        
        # File
        # Convert given w and h to scaling.
        try:
            w0, h0 = self.renderer.imagesize(data)
            type = LAYER_FILE
            s = Point(1.0,1.0)
            if w != None: s.x = float(w) / w0
            if h != None: s.y = float(h) / h0
            w, h = w0, h0           
            return _add_layer(data, type, x, y, w, h, s)
        except: pass
        
        # Fill color
        try:
            r,g,b,a = data.r, data.g, data.b, data.a
            type = LAYER_FILL
            return _add_layer(data, type, x, y, w, h)
        except: pass
        
        # Radial gradient
        try:
            r,g,b,a = data[0].r, data[1].g, data[0].b, data[1].a
            data = data[0], data[1], float(kwargs["spread"])
            type = LAYER_RADIAL_GRADIENT
            return _add_layer(data, type, x, y, w, h)
        except: pass
        
        # Linear gradient
        try:
            r,g,b,a = data[0].r, data[1].g, data[0].b, data[1].a
            data = data[0], data[1]
            type = LAYER_LINEAR_GRADIENT
            return _add_layer(data, type, x, y, w, h)
        except: pass
        
        # Canvas
        try:
            w0, h0 = data.w, data.h
            n = len(data.layers)
            if data == self: raise CanvasInCanvasRecursionError
            type = LAYER_LAYERS
            if w == None: w = data.w
            if h == None: h = data.h
            return _add_layer(data, type, x, y, w, h)
        except: pass
        
        # Path
        # Take the path's x and y into account.
        try:
            data = Path(data[0]).path, data[1], data[2], data[3], data[4]
            (dx,dy), (w0,h0) = data[0].bounds()
            type = LAYER_PATH
            if x == None: x = self.w/2
            if y == None: y = self.h/2
            x += dx
            y += dy
            if w == None: w = w0 + data[4] + PATH_PADDING*2
            if h == None: h = h0 + data[4] + PATH_PADDING*2
            return _add_layer(data, type, x, y, w, h)
        except: pass
        
        # Core Image CIImage object.
        try:
            (x0, y0), (w0, h0) = data.extent()
            type = LAYER_CIIMAGEOBJECT
            return _add_layer(data, type, x, y, w0-x0, h0-y0)
        except: pass
        
        return None            
        
    def layer_fill(self, color, x=None, y=None, w=None, h=None, name=""):
        
        """ Adds a new fill layer to the canvas.
        """
        
        return self.layer(color, None, x, y, w, h, name)      
    
    def layer_gradient(self, type=None, color1=None, color2=None, spread=None, 
                       x=None, y=None, w=None, h=None, name=""):

        """ Adds a new gradient layer to the canvas.
        
        When the spread parameter is given, creates a radial gradient,
        otherwise creates a linear gradient.
        
        """
        
        if type == None:
            type = LAYER_LINEAR_GRADIENT
        if color1 == None:
            color1 = Color(1.0)
        if color2 == None:
            color2 = Color(0.0)

        return self.layer((color1, color2), type, x, y, w, h, name, spread=spread)
        
    def layer_linear_gradient(self, color1=None, color2=None, 
                              x=None, y=None, w=None, h=None, name=""):
        
        """ Adds a new linear gradient to the canvas.
        """
        
        return self.layer_gradient(LAYER_LINEAR_GRADIENT, color1, color2, None, x, y, w, h, name)

    def layer_radial_gradient(self, color1=None, color2=None, spread=0.0, 
                              x=None, y=None, w=None, h=None, name=""):
        
        """ Adds a new radial gradient to the canvas.
        """
                
        return self.layer_gradient(LAYER_RADIAL_GRADIENT, color1, color2, spread, x, y, w, h, name)
    
    def layer_group(self, canvas,
                    x=None, y=None, w=None, h=None, name=""):
        
        """ Adds a new canvas layer to the canvas.
        """
        
        return self.layer(canvas, LAYER_LAYERS, x, y, w, h)
    
    def layer_path(self, path, foreground=None, background=None,
                   stroke=None, strokewidth=None,
                   x=None, y=None, w=None, h=None, name=""):

        """ Adds a new path layer to the canvas.
        
        Paths are filled black by default,
        except when they are applied as masks,
        in which case they are white shine-through by default.
        
        """

        if background == None:
            background = Transparent()
        if foreground == None:
            if self._parent != None and self._parent.mask == self:
                foreground = Color(1.0)
            else:
                foreground = Color(0.0)
                
        if stroke == None:
            stroke = Transparent()
        elif strokewidth == None:
            strokewidth = 1.0
        if strokewidth == None \
        or strokewidth < 0:
            strokewidth = 0.0
        
        return self.layer((path, background, foreground, stroke, strokewidth), LAYER_PATH, x, y, w, h, name)
    
    def find(self, index):
        
        """ Returns the layer with the given name or index.
        
        Browses the canvas recursively:
        if the index is a string, searches layer masks
        and composite layers from the given name as well.
        
        """
        
        return self.layers[index]
    
    def draw(self, x=0, y=0, layers=[], helper=False):
        
        """ Draws the flattened canvas to NodeBox.
        
        Draws the canvas at the given coordinates.
        Throws a CanvasToNodeBox error when unable to draw in NodeBox.
        
        """
        
        self.renderer.draw(self, x, y, layers, helper)
        
    def export(self, name, type=FILE_PNG, compression=None, cmyk=False, layers=[]):
        
        """ Exports the flattened canvas to .jpg, .png or .tif.
        """
        
        self.renderer.export(self, name, type, compression, layers)

    def export_gif(self, name):
        
        self.renderer.export(self, name, FILE_GIF)
        
    def export_png(self, name):
        
        self.renderer.export(self, name, FILE_PNG)
        
    def export_jpg(self, name, quality=1.0):
        
        self.renderer.export(self, name, FILE_JPEG, quality)
        
    def export_tif(self, name, lzw=False, cmyk=False):
        
        self.renderer.export(self, name, FILE_TIFF, lzw, cmyk)

### LAYERS ###########################################################################################
        
class Layers(list):

    """Extends the canvas.layers[] list so it indexes layers names.
    
    When the index is an integer, returns the layer at that  index.
    When the index is a string, returns the first layer with that name.
    
    When a layer is a canvas, or when a layer's alpha mask is a canvas,
    searches that subcanvas recursively.
    
    """
    
    def __getitem__(self, index):

        if isinstance(index, str):
            for layer in self:
                if layer.name == index: 
                    return layer
                if isinstance(layer.data, Canvas):
                    l = layer.data.layers[index]
                    if l != None: return l
                if isinstance(layer.mask, Canvas):
                    l = layer.mask.layers[index]
                    if l != None: return l
            return None
            
        elif 0 <= index < len(self):
            return list.__getitem__(self, index)
        
        else:
            return None

### LAYER ############################################################################################

class Layer:
    
    def __init__(self, canvas, type, data, x, y, w, h, name=""):
        
        self.canvas = canvas
        self.type = type
        self.data = data
        self.name = name
        
        self.layers = None
        if self.type == LAYER_LAYERS:
            self.layers = self.data.layers
        
        self.x = x
        self.y = y
        self._w = w
        self._h = h
        
        self._origin = Point(0.5, 0.5)
        self._flip = (False, False)    
        self._distort = [Point(0.0, 0.0) for i in range(4)]
        self._scale = Point(1.0, 1.0)
        self.rotation = 0
    
        self.opacity = 1.0
        self.blendmode = BLEND_NORMAL
        
        # A mask is a grayscale canvas of layers owned by this layer,
        # and of the same width and height.
        # An alpha mask hides parts of the masked layer
        # where the mask is darker.
        
        self.mask = Canvas(self._w, self._h, self.canvas.renderer)
        self.mask._parent = self
        
        self.brightness = 0.0
        self.contrast = 1.0
        self.saturation = 1.0
        self.inverted = False
        
        self.blur = 0.0
        self.sharpness = 0.0
        self.filters = []
        self._filters_first = True
        
        self.hidden = False
    
    def is_file(self)            : return (self.type == LAYER_FILE)
    def is_fill(self)            : return (self.type == LAYER_FILL)    
    def is_gradient(self)        : return (self.type == LAYER_LINEAR_GRADIENT)    
    def is_linear_gradient(self) : return (self.type == LAYER_RADIAL_GRADIENT)
    def is_radial_gradient(self) : return (self.type == LAYER_LINEAR_GRADIENT)    
    def is_path(self)            : return (self.type == LAYER_PATH)
    def has_layers(self)         : return (self.type == LAYER_LAYERS)
    def is_mask(self)            : return (self.canvas._parent != None and 
                                           self.canvas._parent.mask == self.canvas)
        
    def index(self):
        
        """Returns this layer's index in the canvas.layers[].
        
        Searches the position of this layer in the canvas'
        layers list, return None when not found.
        
        """
        
        if self.canvas == None:
            return None
        else:
            return self.canvas.layers.index(self)
    
    def arrange(self, where):
        
        """ Moves the layer either forwards or backwards.
        """
        
        i = self.index()
        j = None
        if where == ARRANGE_UP    : j = i+1
        if where == ARRANGE_DOWN  : j = i-1
        if where == ARRANGE_FRONT : j = len(self.canvas.layers)
        if where == ARRANGE_BACK  : j = 0
        
        if j != None:
            del self.canvas.layers[i]
            j = max(0, min(j, len(self.canvas.layers)))
            self.canvas.layers.insert(j, self)
            return j
           
    def arrange_up(self)    : return self.arrange(ARRANGE_UP)
    def arrange_down(self)  : return self.arrange(ARRANGE_DOWN)
    def arrange_front(self) : return self.arrange(ARRANGE_FRONT)
    def arrange_back(self)  : return self.arrange(ARRANGE_BACK)

    def hide(self):
        
        """ Hides the layer from the output.
        
        This is different than a completely transparent layer,
        which is still rendered adn might have thousands of
        sublayers that will also be rendered.
        A hidden layer is never rendered.
        
        """
        
        self.hidden = True

    def copy(self):
        
        """ Creates a copy of the layer.
        
        Creates and returns deep copy of the layer.
        This means for example that the layers in the mask
        are recursively copied, that new copies are made of colors
        in the gradient
        
        """
        
        if self.type == LAYER_FILE:
            data = self.data
        if self.type == LAYER_FILL:
            data = Color(self.data)
        if self.type == LAYER_LINEAR_GRADIENT:
            data = (Color(self.data[0]), Color(self.data[1]))
        if self.type == LAYER_RADIAL_GRADIENT:
            data = (Color(self.data[0]), Color(self.data[1]), self.data[2])
        if self.type == LAYER_LAYERS:
            data = self.data.copy()
        if self.type == LAYER_PATH:
            data = (self.data[0].copy(), Color(self.data[1]), Color(self.data[2]), Color(self.data[3]), self.data[4])
            
        layer = Layer(self.canvas, self.type, data, self.x, self.y, self._w, self._h)

        layer._origin = Point(self._origin.x, self._origin.y)
        layer._flip = self._flip
        layer._distort = [Point(self._distort[i].x, self._distort[i].y) for i in range(4)]
        layer._scale = Point(self._scale.x, self._scale.y)
        layer.rotation = self.rotation
    
        layer.opacity = self.opacity
        layer.blendmode = self.blendmode
        
        layer.mask = self.mask.copy()
        layer.mask._parent = layer

        layer.brightness = self.brightness
        layer.contrast = self.contrast
        layer.saturation = self.saturation
        layer.inverted = self.inverted
        
        layer.blur = self.blur
        layer.sharpness = self.sharpness
        layer.filters = [(filter, params) for filter, params in self.filters]
        
        return layer

    def duplicate(self):
        
        """ Adds a copy of the layer on top of this one.
        
        Creates a copy of this layer,
        appends it to the canvas right above this layer,
        and returns the index of the new layer.
        
        """
        
        i = self.index()
        layer = self.copy()
        self.canvas.layers.insert(i+1, layer)
        
        return layer

    def origin(self, x=None, y=None):
        
        """ Sets the transformation origin point.
        
        The origin point is the layer's anchor/pivot/orbit:
        it is placed at x and y and is the point
        around which the layer rotates,
        and from which the layer scales and flips.
        
        """
        
        def f(s):
            if s == ORIGIN_LEFT   : return 0.0
            if s == ORIGIN_TOP    : return 0.0
            if s == ORIGIN_RIGHT  : return 1.0
            if s == ORIGIN_BOTTOM : return 1.0
            if s == ORIGIN_CENTER : return 0.5
            return s    
        
        x = f(x)
        y = f(y)
            
        if isinstance(x, float):
            self._origin.x = x
        if isinstance(y, float):
            self._origin.y = y
            
        return (self._origin.x, self._origin.y)
    
    def origin_top_left(self)      : return self.origin(ORIGIN_LEFT, ORIGIN_TOP)
    def origin_top_right(self)     : return self.origin(ORIGIN_RIGHT, ORIGIN_TOP)
    def origin_top_center(self)    : return self.origin(ORIGIN_CENTER, ORIGIN_TOP)
    def origin_bottom_left(self)   : return self.origin(ORIGIN_LEFT, ORIGIN_BOTTOM)
    def origin_bottom_right(self)  : return self.origin(ORIGIN_RIGHT, ORIGIN_BOTTOM)
    def origin_bottom_center(self) : return self.origin(ORIGIN_CENTER, ORIGIN_BOTTOM)    
    def origin_left_center(self)   : return self.origin(ORIGIN_LEFT, ORIGIN_CENTER)
    def origin_right_center(self)  : return self.origin(ORIGIN_RIGHT, ORIGIN_CENTER)
    def origin_center(self)        : return self.origin(ORIGIN_CENTER, ORIGIN_CENTER)
    
    def bounds(self):
        
        """ Returns the left, top, right, bottom in pixels.
        
        Calculates the layer's bounding box based on
        its original size and position modified by its
        scaling, rotation and origin point.
        Gets the coordinates of the corner points to
        calculate maximum extent.
        
        This method is also handy to check if the renderer
        is handling layer transformations correctly.
        
        When the canvas is scaled,
        you need to multiply left and right by
        the canvas horizontal scaling and top and bottom
        by the canvas vertical scaling to have the
        correct bounds for display purposes 
        (but not so for editing).
        
        """
        
        from math import sqrt, pow
        from math import sin, cos, atan, pi, radians, degrees  
        
        def distance(x0, y0, x1, y1):
            return sqrt(pow(x1-x0, 2) + pow(y1-y0, 2))
    
        def angle(x0, y0, x1, y1):
            a = degrees( atan((y1-y0) / (x1-x0+0.00001)) ) + 360
            if x1-x0 < 0: a += 180
            return 360 - a

        if isinstance(self.canvas._parent, Layer):
            return self.canvas._parent.bounds()

        w = self._w * self._scale.x
        h = self._h * self._scale.y
        ox = self.x + self._origin.x * w
        oy = self.y + self._origin.y * h        
        
        l = t = float("infinity")
        r = b = float("-infinity") 
        
        corners = [(self.x, self.y), 
                   (self.x+w, self.y), 
                   (self.x+w, self.y+h), 
                   (self.x, self.y+h)]
        
        for i in range(len(corners)):
            dx, dy = corners[i]
            dx += self._distort[i].x * w
            dy += self._distort[i].y * h
            a = self.rotation - angle(ox, oy, dx, dy)
            d = distance(ox, oy, dx, dy)
            dx = self.x + d * cos(radians(a))
            dy = self.y + d * sin(radians(a))
            l = min(l, dx)
            r = max(r, dx)
            t = min(t, dy)
            b = max(b, dy)    
        
        return (l, t, r, b)
    
    def size(self):
        
        """ Returns the layer's size.
        
        Returns the width and height of the layer
        after it has been rotated and scaled
        (whereas the base width and height properties
        contain the size of the layer's data).
        
        """
        
        l, t, r, b = self.bounds()
        return (r-l, b-t)
    
    def translate(self, x, y):
        
        """ Places the layer at the given position.
        
        The width and height can be supplied as
        coordinates relative to the canvas size (between 0.0 and 1.0), 
        or as absolute coordinates in pixels.
        
        """

        if isinstance(x, float):
            x = x * self.canvas.w
        if isinstance(y, float):
            y = y * self.canvas.h        
        self.x = x
        self.y = y
    
    def scale(self, w=None, h=None):
        
        """ Scales the layer horizontally and vertically.
        
        The width and height can be supplied as relative
        coordinates (between 0.0 and 1.0), or as absolute
        coordinates in pixels. If only parameter is supplied,
        scales the layer proportionally.
        
        """
        
        if w != None and h == None: 
            if isinstance(w, float): h = w
            else: h = int( float(w) / self._w * self._h )
        if h != None and w == None: 
            if isinstance(h, float): w = h
            else: w = int( float(h) * self._w / self._h )
            
        if isinstance(w, float):
            self._scale.x = w
        if isinstance(h, float):
            self._scale.y = h
        if isinstance(w, int):
            self._scale.x = float(w) / self._w
        if isinstance(h, int):
            self._scale.y = float(h) / self._h
            
        return (self._scale.x, self._scale.y)
    
    def rotate(self, degrees):
        
        """ Sets the layer's angle to the given degrees.
        """
        
        self.rotation = degrees
        
    def flip(self, horizontal=False, vertical=False):
        
        """ Flips the layer horizontally or vertically.
        """
        
        if horizontal == True:
            self.flip_horizontal()
        if vertical == True:
            self.flip_vertical()
            
        return self._flip
    
    def flip_horizontal(self):
        
        fx, fy = self._flip
        self._flip = (not fx, fy)
    
    def flip_vertical(self):
        
        fx, fy = self._flip
        self._flip = (fx, not fy)
        
    def distort(self, dx0=0.0, dy0=0.0, dx1=0.0, dy1=0.0, dx2=0.0, dy2=0.0, dx3=0.0, dy3=0.0):
        
        """ Distorts the layer by moving its corner points.
        
        The given coordinates can be either relative
        to the corner positions (between 0.0 and 1.0),
        or absolute in pixels.
        
        """
        
        self._distort = [
            Point(dx0, dy0),
            Point(dx1, dy1),
            Point(dx2, dy2),
            Point(dx3, dy3)
            ]

        for pt in self._distort:
            if isinstance(pt.x, int):
                pt.x = float(pt.x) / self._w
            if isinstance(pt.y, int):
                pt.y = float(pt.y) / self._h
        
    def blend(self, opacity=None, mode=None):
        
        """ Applies transparency and compositing to the layer.
        
        Opacity ranges between 0.0 and 100.0
        Standard blending modes (i.e. how this layer mixes with layers below) are 
        screen, multiply, overlay, hue and color; and it is preferred
        the renderer knows how to handle softlight and darklight as well.
        
        """
        
        if isinstance(opacity, int):
            self.opacity = opacity * 0.01
        if isinstance(opacity, float):
            self.opacity = opacity
        self.opacity = max(0.0, min(self.opacity, 1.0))
        if mode != None:
            self.blendmode = mode
            
        return (self.opacity, self.blendmode)

    def blend_normal(self)    : self.blendmode = BLEND_NORMAL
    def blend_screen(self)    : self.blendmode = BLEND_SCREEN
    def blend_multiply(self)  : self.blendmode = BLEND_MULTIPLY
    def blend_overlay(self)   : self.blendmode = BLEND_OVERLAY
    def blend_softlight(self) : self.blendmode = BLEND_SOFTLIGHT
    def blend_hardlight(self) : self.blendmode = BLEND_HARDLIGHT
    def blend_hue(self)       : self.blendmode = BLEND_HUE
    def blend_color(self)     : self.blendmode = BLEND_COLOR
        
    def adjust(self, brightness=None, contrast=None, saturation=None, invert=False):
        
        """ Applies color adjustments to the layer.
        
        Standard adjustments are brightness, contrast, saturation and invert.
        Brightness ranges between -1.0 and 1.0
        Contrast ranges between 0.25 and 4.0 (default is 1.0)
        Saturation ranges between 0.0 and 2.0 (default is 1.0)
        
        """
        
        if brightness != None:
            self.adjust_brightness(brightness)
        if contrast != None:
            self.adjust_contrast(contrast)
        if saturation != None:
            self.adjust_saturation(saturation)
            
        if invert != False:
            self.invert()
    
    def adjust_brightness(self, value=0.0):
        
        self.brightness = max(-1.0, min(value, 1.0))

    def adjust_contrast(self, value=1.0):
        
        self.contrast = max(0.25, min(value, 4.0))
        
    def adjust_saturation(self, value=1.0):
        
        self.saturation = max(0.0, min(value, 2.0))

    def desaturate(self):
        
        self.saturation = 0.0
        
    def invert(self):
        
        self.inverted = not self.inverted
        
    def filter(self, name, **kwargs):
        
        """ Applies an effect filter to the layer.
        
        Standard filters are blur and sharpen.
        Blur ranges between 0.0 and 100.0
        Sharpen ranges between 0.0 and 100.0
        Ideally the canvas renderer uses Gaussian Blur and
        Unsharp Mask respectively to render the effects.
        
        Various other filters are renderer-dependent.
        You can use them by supplying a name parameter
        and other parameters specific to the effect.
        For example:
        canvas.layers[i].filter(name=canvas.renderer.FILTER_KALEIDOSCOPE, count=10, dx=-100)
    
        """

        if name == "blur":
            self.blur = kwargs["amount"]
            self.blur = max(0.0, min(self.blur, 100.0))
            
        elif name == "sharpen":
            self.sharpness = kwargs["amount"]
            self.sharpness = max(0.0, min(self.sharpness, 100.0))
            
        elif name != "":
            filter = name
            try: filter = self.canvas.renderer.aliases[filter]
            except: pass
            params = {}
            for param in self.canvas.renderer.filters[filter]:
                if param in kwargs:
                    params[param] = kwargs[param]
                else:
                    params[param] = self.canvas.renderer.filters[filter][param]
            self.filters.append((filter, params))

    # Filters are renderer-dependent because it is highly unlikely 
    # a PIL-renderer would be able to perform exactly the same effects as Core Image.
    # The Layer class should be renderer independent,
    # which is why I'm not very happy with the following declarations.
    # But they are user-friendly though.

    def filter_blur(self, amount=10.0)         : self.filter("blur", **{"amount":amount})
    def filter_sharpen(self, amount=2.5)       : self.filter("sharpen", **{"amount":amount})
    
    def filter_zoomblur(self, **kwargs)        : self.filter(self.canvas.renderer.FILTER_ZOOMBLUR, **kwargs)
    def filter_motionblur(self, **kwargs)      : self.filter(self.canvas.renderer.FILTER_MOTIONBLUR, **kwargs)    
    def filter_bumpdistortion(self, **kwargs)  : self.filter(self.canvas.renderer.FILTER_BUMPDISTORTION, **kwargs)
    def filter_holedistortion(self, **kwargs)  : self.filter(self.canvas.renderer.FILTER_HOLEDISTORTION, **kwargs)
    def filter_twirl(self, **kwargs)           : self.filter(self.canvas.renderer.FILTER_TWIRLDISTORTION, **kwargs)
    def filter_kaleidoscope(self, **kwargs)    : self.filter(self.canvas.renderer.FILTER_KALEIDOSCOPE, **kwargs)
    def filter_perspectivetile(self, **kwargs) : self.filter(self.canvas.renderer.FILTER_PERSPECTIVETILE, **kwargs)
    def filter_starshine(self, **kwargs)       : self.filter(self.canvas.renderer.FILTER_STARSHINEGENERATOR, **kwargs)
    def fitler_bloom(self, **kwargs)           : self.filter(self.canvas.renderer.FILTER_BLOOM, **kwargs)
    def filter_lighting(self, **kwargs)        : self.filter(self.canvas.renderer.FILTER_SPOTLIGHT, **kwargs)
    def filter_shading(self, **kwargs)         : self.filter(self.canvas.renderer.FILTER_SHADEDMATERIAL, **kwargs)
    def filter_levels(self, **kwargs)          : self.filter(self.canvas.renderer.FILTER_COLORMATRIX, **kwargs)
   
    def filters_first(self, b=None):
        
        """ Determines when filters are rendered on this layer.
        
        Either filters are applied to the layer
        before scaling, distorting and rotating it,
        or applied last, after having transformed the layer.
        
        """
        
        if isinstance(b, bool):
            self._filters_first = b
        
        return self._filters_first
        
    def pixels(self):
        
        """ Returns pixel-based information about the layer.
        
        Returns a Pixels object based on a render
        of this layer.
        
        """
        
        return self.canvas.renderer.pixels(self)

    def _render(self):
        
        return self.canvas.renderer.render(self)

### RENDERER #########################################################################################

class Renderer:
    
    """ A Canvas renderer interface.
    
    Since the canvas and layer model is non-destructive,
    merging and compositing layers is handled by a separate renderer.
    A renderer might be Core Image on Mac OS X or PIL on other platforms.
    
    A renderer has the following tasks:
    
    1) be able to identify an object it rendered
    2) be able to determine an image file's dimensions
    3) be able to produce a pixels array from the layer
    4) be able to render a layer
    5) be able to merge and composite rendered layers
    6) be able to draw a flattened image in NodeBox
    7) be able to export a flattened .png, .jpg and .tif
    8) have a dictionary of custom filters and their parameters
    9) have a name.
    
    A renderer is able to generate the following layers:
        
    1) image from file
    2) solid fill color
    3) linear gradient with two colors
    4) radial gradient with two colors and spread option
    
    A renderer supports the following compositing:
    
    1) adjustments: brightness, contrast, saturation, invert
    2) transparency, and alpha masks (defined by a Canvas)
    3) filters: blur and sharpen
    4) blend modes: multiply, screen, overlay, hue, color
    
    A renderer supports the following transformations:
    
    1) flip
    2) distort
    3) scale, handled before rotating
    4) rotate, handled before translating
    5) translate
    
    Transformations originate from
    the Layer's origin point and are processed
    after alpha masks.
        
    """
    
    def __init__(self):
        self.name = ""
        self.filters = {}
    
    def is_render(self, object):
        pass
    
    def imagesize(self, path):
        pass
    
    def pixels(self, layer):
        pass
    
    def render(self, layer):
        pass
    
    def merge(self, canvas, layers=[]): 
        pass
    
    def draw(self, canvas, x, y, layers=[]): 
        pass
        
    def export(self, canvas, name, type, layers=[]):
        pass

### COREIMAGERENDERER ################################################################################

from AppKit import *
from Foundation import *     
from CoreGraphics import *
class CoreImageRenderer(Renderer):

    """ A Canvas Core Image renderer.
    """

    def __init__(self):
        
        self.name = "CoreImage"

        # A helper draws visual feedback in NodeBox.
        self.helper = CoreImageHelper(self)

        # A list of all implemented filters
        # currently available from Core Image.
        
        self.FILTER_COLORMATRIX        = "CIColorMatrix"
        self.FILTER_MOTIONBLUR         = "CIMotionBlur"
        self.FILTER_ZOOMBLUR           = "CIZoomBlur"
        self.FILTER_BUMPDISTORTION     = "CIBumpDistortion"
        self.FILTER_HOLEDISTORTION     = "CIHoleDistortion"
        self.FILTER_TWIRLDISTORTION    = "CITwirlDistortion"
        self.FILTER_KALEIDOSCOPE       = "CIKaleidoscope"
        self.FILTER_PERSPECTIVETILE    = "CIPerspectiveTile"
        self.FILTER_STARSHINEGENERATOR = "CIStarShineGenerator"
        self.FILTER_BLOOM              = "CIBloom"
        self.FILTER_SPOTLIGHT          = "CISpotLight"
        self.FILTER_SHADEDMATERIAL     = "CIShadedMaterial"
        
        # A property description list
        # for each filter.
        
        self.filters = {
            self.FILTER_COLORMATRIX        : {"r": 1.0, "g": 1.0, "b": 1.0, "a": 1.0},
            self.FILTER_MOTIONBLUR         : {"radius": 20, "angle": 0},
            self.FILTER_ZOOMBLUR           : {"amount": 20, "dx": 0, "dy": 0},
            self.FILTER_BUMPDISTORTION     : {"dx": 0, "dy": 0, "radius": 300, "scale": 0.5},
            self.FILTER_HOLEDISTORTION     : {"dx": 0, "dy": 0, "radius": 300},
            self.FILTER_TWIRLDISTORTION    : {"dx": 0, "dy": 0, "radius": 150, "angle": 100},
            self.FILTER_KALEIDOSCOPE       : {"count": 10, "dx": 0, "dy": 0},
            self.FILTER_PERSPECTIVETILE    : {"dx0": 0, "dy0": 0, "dx1": 0, "dy1": 0, "dx2": 0, "dy2": 0, "dx3": 0, "dy3": 0},
            self.FILTER_STARSHINEGENERATOR : {"dx": 0, "dy": 0, "radius": 25, "x_scale": 10, "x_angle": 0, "x_width": 0.5, "epsilon": -5.0},
            self.FILTER_BLOOM              : {"radius": 10, "intensity": 1.0 },        
            self.FILTER_SPOTLIGHT          : {"dx0": 100, "dy0": 100, "dz0": 300, "dx1": 0, "dy1": 0, "brightness": 3.0, "concentration": 0.3, "color": None, "helper": False},
            self.FILTER_SHADEDMATERIAL     : {"radius": 20, "texture": None, "dx": 0, "dy": 0}
        }
        
        # NodeBox sliders for each filter parameter.
        
        for filter in self.filters:
            self.filters[filter]["interface"] = False
        
        # Short names for each filter.
        # It's easier to write layer.filter(name="bloom")
        # than to write layer.filter(name=canvas.renderer.FILTER_BLOOM)
        
        self.aliases = {
            "levels"          : self.FILTER_COLORMATRIX,
            "motionblur"      : self.FILTER_MOTIONBLUR,
            "zoomblur"        : self.FILTER_ZOOMBLUR,
            "bumpdistortion"  : self.FILTER_BUMPDISTORTION,
            "holedistortion"  : self.FILTER_HOLEDISTORTION,
            "twirl"           : self.FILTER_TWIRLDISTORTION,
            "kaleidoscope"    : self.FILTER_KALEIDOSCOPE,
            "perspectivetile" : self.FILTER_PERSPECTIVETILE,
            "starshine"       : self.FILTER_STARSHINEGENERATOR,
            "bloom"           : self.FILTER_BLOOM,
            "lighting"        : self.FILTER_SPOTLIGHT,
            "shading"         : self.FILTER_SHADEDMATERIAL,
            # Deprecated aliases >
            "motion"          : self.FILTER_MOTIONBLUR,
            "zoom"            : self.FILTER_ZOOMBLUR,
            "bump"            : self.FILTER_BUMPDISTORTION,
            "hole"            : self.FILTER_HOLEDISTORTION,
            "tile"            : self.FILTER_PERSPECTIVETILE,
            "star"            : self.FILTER_STARSHINEGENERATOR
        }

    def filter(self, name, input=None, parameters={}):
        
        """ Generates a CIFilter from the given input CIImage.
        
        The specific parameters for this filter are passed as a dictionary.
        The return value is a filtered CIImage.
        
        """
        
        filter = CIFilter.filterWithName_(name)
        filter.setDefaults()
        if input != None:
            filter.setValue_forKey_(input, "inputImage")
        for key in parameters.keys():
            value = parameters[key]
            filter.setValue_forKey_(value, key)
        return filter.valueForKey_("outputImage") 
    
    def is_render(self, object):
        
        return isinstance(object, CIImage)
        
    def imagesize(self, path):
        
        url = NSURL.fileURLWithPath_(path)
        w, h = CIImage.imageWithContentsOfURL_(url).extent()[1]
        return w, h
    
    def image(self, type, data, w, h):
    
        """ Returns a CIImage based on the given layer properties.
        
        Images can be created from files, colors,
        or a canvas of layers base on the layer's type.
        
        An PNG image with alpha information may contain a
        subtle white edge near the transparency,
        instead supply a TIFF with layers and transparency. 
        This is noticable in straight masks 
        (straight horizontal/vertical holes).
        
        """
    
        # We cannot import this constant so guess its value.
        # If something weird happens in the future, check this one.
    
        kCIFormatRGBA8 = 1
    
        if type == LAYER_FILE:
            
            # The layer's source is an image file.
            
            url = NSURL.fileURLWithPath_(data)
            img = CIImage.imageWithContentsOfURL_(url)
        
        if type == LAYER_FILL:
            
            # The layer's source is a single color
            # for which we create a fill rectangle
            # using a CIImageAccumulator.
            
            r = NSRect((0,0), (w,h))
            a = CIImageAccumulator.imageAccumulatorWithExtent_format_(r, kCIFormatRGBA8)
            c = data
            c = CIColor.colorWithRed_green_blue_alpha_(c.r, c.g, c.b, c.a)        
            img = self.filter("CIConstantColorGenerator", parameters={"inputColor": c})
            a.setImage_(img)
            img = a.image()
        
        if type == LAYER_LINEAR_GRADIENT:
            
            # The layer's source are two colors
            # from which we create a vertical linear gradient
            # spread equally across the layer's height.
            
            r = NSRect((0,0), (w,h))
            a = CIImageAccumulator.imageAccumulatorWithExtent_format_(r, kCIFormatRGBA8)
            c0, c1 = data
            c0 = CIColor.colorWithRed_green_blue_alpha_(c0.r, c0.g, c0.b, c0.a)
            c1 = CIColor.colorWithRed_green_blue_alpha_(c1.r, c1.g, c1.b, c1.a)
            img = self.filter("CILinearGradient", 
                   parameters={"inputColor0": c0, 
                               "inputColor1": c1,
                               "inputPoint0": CIVector.vectorWithX_Y_(0, 0),
                               "inputPoint1": CIVector.vectorWithX_Y_(0, h)})
            a.setImage_(img)
            img = a.image()

        if type == LAYER_RADIAL_GRADIENT:
 
            # The layer's source are two colors
            # from which we create a radial gradient
            # spread across either the layer's width 
            # or the layer's height, whichever is smaller.
 
            r = NSRect((0,0), (w,h))
            a = CIImageAccumulator.imageAccumulatorWithExtent_format_(r, kCIFormatRGBA8)
            c0, c1, spread = data
            c0 = CIColor.colorWithRed_green_blue_alpha_(c0.r, c0.g, c0.b, c0.a)
            c1 = CIColor.colorWithRed_green_blue_alpha_(c1.r, c1.g, c1.b, c1.a)
            spread = max(0.0, min(spread, 0.99))
            radius = min(w/2, h/2)
            img = self.filter("CIRadialGradient", 
                   parameters={"inputColor0" : c0, 
                               "inputColor1" : c1,
                               "inputCenter" : CIVector.vectorWithX_Y_(w/2, h/2),
                               "inputRadius0": radius*spread,
                               "inputRadius1": radius})
            a.setImage_(img)
            img = a.image()
        
        if type == LAYER_PATH:
            
            # The layer's source consists of vector curves
            # which we need to transform to
            # bitmap information.
            
            path, bg, fg, s, sw = data
            sw = float(sw)
            (px, py), (pw, ph) = path.bounds()
            img = NSImage.alloc().initWithSize_((w,h))
            img.lockFocus()
            NSColor.colorWithDeviceRed_green_blue_alpha_(bg.r, bg.g, bg.b, bg.a).set()
            NSRectFill(((0,0), (w,h)))
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(w/2, h/2)
            t.scaleXBy_yBy_(1, -1)
            t.translateXBy_yBy_(-px+sw/2+PATH_PADDING, -py+sw/2+PATH_PADDING)
            t.translateXBy_yBy_(-w/2, -h/2)
            t.set()
            NSColor.colorWithDeviceRed_green_blue_alpha_(fg.r, fg.g, fg.b, fg.a).set()
            path.fill()
            if sw != None and sw > 0:
                NSColor.colorWithDeviceRed_green_blue_alpha_(s.r, s.g, s.b, s.a).set()
                path.setLineWidth_(sw)
                path.stroke()            
            img.unlockFocus()
            img = img.TIFFRepresentation()
            img = CIImage.alloc().initWithData_(img)
        
        if type == LAYER_LAYERS:
            
            # The layer is in fact a canvas of layers,
            # flatten it and use the resulting CIImage.
            
            img = self.merge(data)
        
        if type == LAYER_CIIMAGEOBJECT:
            
            # The layer's source is a CIImage object.
            
            img = data
            
        return img
    
    def pixels(self, layer):
        
        """ Returns a Pixels object based on the layer.
        """
        
        img = self.render(layer)
        return CoreImagePixels(self, layer, img)
    
    def render_adjustments(self, layer, img):
            
        """ Render layer adjustments.
        
        Applies the layer's adjustments to the given image:
        brightness, contrast, saturation and invert.
        
        """
            
        if layer.brightness != 0.0 \
        or layer.contrast != 1.0 \
        or layer.saturation != 1.0:
            b = max(-1.0, min(layer.brightness, 1.0))
            c = max(0.25, min(layer.contrast, 4.0))
            s = max(0.0, min(layer.saturation, 2.0))
            p = {"inputBrightness": b, "inputContrast": c, "inputSaturation": s}
            img = self.filter("CIColorControls", img, p)
                
        if layer.inverted == True:
            img = self.filter("CIColorInvert", img)
            
        return img
    
    def render_filters(self, layer, img):
        
        """ Render layer filters.
        
        Applies the layer's filters to the given image: blur and sharpen.
        This renderer mhas other specific filters that are also
        processed here.
        
        """
        
        if layer.blur > 0.0:
            b = max(0.0, min(layer.blur, 100.0))
            p = {"inputRadius": b}
            img = self.filter("CIGaussianBlur", img, p)
        
        if layer.sharpness > 0.0:
            s = max(0.0, min(layer.sharpness, 100.0))
            p = {"inputRadius": s, "inputIntensity": 0.5}
            img = self.filter("CIUnsharpMask", img, p)

        for filter, options in layer.filters:
            if filter in self.filters:
                f = getattr(self, "render_filter_" + filter[2:].lower())
                
                # Filter options can be supllied by NodeBox sliders
                
                if self.helper != None \
                and "interface" in options \
                and options["interface"] == True:
                    options = self.helper.interface(filter)
                    if options["render"] == True: 
                        img = f(layer, img, options)
                      
                else:
                    img = f(layer, img, options)

        # Reset the count of interfaced filters
        # so we don't have to reload the library.

        if self.helper != None:
            self.helper._i = 1

        return img

    def render_filter_colormatrix(self, layer, img, options):
        
        # Apply the Core Image Color t filter.
        # This powerful filter has functionalities
        # comparable to PhotoShop levels or curves.
        # For each RGBA channel you can specify
        # a multiplication factor, increasing or decreasing
        # the channel's prominence.
        # Instead of a single value a four-tuple can
        # be supplied as well (for instance, to increase
        # the blue in the R channel.
        
        # Setting r=0, g=0, b=0 and a=1
        # removes all color information while
        # keeping the alpha information.
        # This results in the image's alpha mask,
        # useful as a shadow for example.
        # I.e. setting a channel to zero removes it.
        
        v = []
        for channel in "rgba":
            v.append(options[channel])
        for i in range(len(v)):
            if  not isinstance(v[i], list) \
            and not isinstance(v[i], tuple):
                x = v[i]
                v[i] = [0, 0, 0, 0]
                v[i][i] = x
            else:
                v[i] = list(v[i])
            if i == 3: 
                v[i][3] -= 0.000001
            v[i] = CIVector.vectorWithX_Y_Z_W_(v[i][0], v[i][1], v[i][2], v[i][3])

        p = {
            "inputRVector" : v[0], 
            "inputGVector" : v[1], 
            "inputBVector" : v[2], 
            "inputAVector" : v[3]
        }        
        img = self.filter(self.FILTER_COLORMATRIX, img, p)
        
        return img 

    def render_filter_motionblur(self, layer, img, options):
    
        # Apply the Core Image Motion Blur filter effect,
        # generating a swooshy directional blur.
        # This filter is shaky in certain situations,
        # e.g. crashes when combined with tiling.

        for filter, params in layer.filters:
            if filter == self.FILTER_PERSPECTIVETILE:
                return img

        (x,y), (w,h) = img.extent()
        
        from math import radians
        
        r = options["radius"]
        a = options["angle"]
        
        # If the image is opaque at the edges it will
        # will stretch out beyond its bounds.
        # To solve this, we add a transparent 1-pixel border/gutter
        # around the layer.        
        
        if w < layer.canvas.w*10 and h < layer.canvas.h*10:
            
            base = self.image(LAYER_FILL, Transparent(), w+2, h+2)
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(-1, -1)
            base = self.filter("CIAffineTransform", base, {"inputTransform": t})
            img = self.filter("CISourceOverCompositing", img, {"inputBackgroundImage": base}) 
    
        r = max(0.0, min(r, 100.0))
        a = radians(a)
        p = {"inputRadius": r, "inputAngle": a}
        img = self.filter(self.FILTER_MOTIONBLUR, img, p)
        
        # After applying the filter w and h will be near infinity.
        # To solve this bug(?) we crop to something workable.
        
        d = 20 + r*4
        v = CIVector.vectorWithX_Y_Z_W_(x-d, y-d, w+d*2, h+d*2)
        img = self.filter("CICrop", img, {"inputRectangle" : v})

        return img   

    def render_filter_zoomblur(self, layer, img, options):

        # Apply the Core Image Zoom Blur filter effect,
        # simulating the effect of zooming the camera while capturing the image.

        a = options["amount"]
        dx = options["dx"]
        dy = options["dy"]
        
        a = max(0.0, min(a, 200.0))
        o = CIVector.vectorWithX_Y_(layer._w*0.5+dx, layer._h*0.5-dy)
        p = {"inputAmount": a, "inputCenter": o}
        img = self.filter(self.FILTER_ZOOMBLUR, img, p)

        return img  

    def render_filter_bumpdistortion(self, layer, img, options):
        
        # Apply the Core Image Bump Distortion filter effect,
        # generating a pinch or bump in the layer.
                    
        dx = options["dx"]
        dy = options["dy"]
        r = options["radius"]
        s = options["scale"]
        
        r = max(0.0, min(r, 600.0))
        s = max(-1.0, min(s, 1.0))
        o = CIVector.vectorWithX_Y_(layer._w*0.5+dx, layer._h*0.5-dy)
        p = {"inputCenter": o, "inputRadius": r, "inputScale": s}
        img = self.filter(self.FILTER_BUMPDISTORTION, img, p)

        return img

    def render_filter_holedistortion(self, layer, img, options):
        
        # Apply the Core Image Hole Distortion filter effect,
        # pushing the layer's pixels outwards.
                    
        dx = options["dx"]
        dy = options["dy"]
        r = options["radius"]
        
        r = max(0.0, min(r, 1000.0))
        if r > 0:
            o = CIVector.vectorWithX_Y_(layer._w*0.5+dx, layer._h*0.5-dy)
            p = {"inputCenter": o, "inputRadius": r}
            img = self.filter(self.FILTER_HOLEDISTORTION, img, p)

        return img

    def render_filter_twirldistortion(self, layer, img, options):
        
        # Apply the Core Image Twirl Distortion filter effect,
        # generating wave motion in the layer.
        
        from math import radians
                            
        dx = options["dx"]
        dy = options["dy"]
        r = options["radius"]
        a = options["angle"]
        
        r = max(0.0, min(r, 500.0))
        a = radians(a)
        o = CIVector.vectorWithX_Y_(layer._w*0.5+dx, layer._h*0.5-dy)
        p = {"inputCenter": o, "inputRadius": r, "inputAngle": a}
        img = self.filter(self.FILTER_TWIRLDISTORTION, img, p)

        return img
        
    def render_filter_kaleidoscope(self, layer, img, options):
        
        # Apply the Core Image Kaleidoscope filter effect,
        # generating a fractal-like output.
        
        count = options["count"]
        dx = options["dx"]
        dy = options["dy"]
    
        if count > 0:

            count = max(0, min(count, 100))
            o = CIVector.vectorWithX_Y_(layer._w*0.5+dx, layer._h*0.5+dy)
            p = {"inputCount": count, "inputCenter": o}
            img = self.filter(self.FILTER_KALEIDOSCOPE, img, p)
        
        return img

    def render_filter_perspectivetile(self, layer, img, options):

        # Apply the Core Image Perspective Tile filter effect.
        # This filter distorts the layer by translating its
        # corner points, and then tiling that on a plane.
        
        (x,y), (w,h) = img.extent()
        
        dx0 = options["dx0"]
        dy0 = options["dy0"] + h
        dx1 = options["dx1"] + w
        dy1 = options["dy1"] + h
        dx2 = options["dx2"] + w
        dy2 = options["dy2"]
        dx3 = options["dx3"]
        dy3 = options["dy3"]
        
        p = {
            "inputTopLeft"     : CIVector.vectorWithX_Y_(dx0, dy0),
            "inputTopRight"    : CIVector.vectorWithX_Y_(dx1, dy1),
            "inputBottomRight" : CIVector.vectorWithX_Y_(dx2, dy2),
            "inputBottomLeft"  : CIVector.vectorWithX_Y_(dx3, dy3)
        }
        img = self.filter(self.FILTER_PERSPECTIVETILE, img, p)
        
        return img

    def render_filter_starshinegenerator(self, layer, img, options):

        # Apply the Core Image Starshine Generator filter effect.
        # This filter maps stars and sun bursts on the layer,
        # which is usually a new transparent layer.        

        from math import radians
                            
        dx = options["dx"]
        dy = options["dy"]
        r = options["radius"]
        s = options["x_scale"]
        a = options["x_angle"]
        w = options["x_width"]
        e = options["epsilon"]
        
        r = max(0.0, min(r, 300.0))
        s = max(0.0, min(s, 100.0))
        a = radians(a)
        e = max(-8.0, min(e, 8.0))
        o = CIVector.vectorWithX_Y_(layer._w*0.5+dx, layer._h*0.5-dy)
        p = {
            "inputCenter": o, 
            "inputRadius": r, 
            "inputCrossScale": s, 
            "inputCrossAngle": a,
            "inputCrossWidth": w,
            "inputEpsilon": e
        }
        starshine = self.filter(self.FILTER_STARSHINEGENERATOR, None, p)
        img = self.filter("CISourceOverCompositing", starshine, {"inputBackgroundImage": img})       

        v = CIVector.vectorWithX_Y_Z_W_(0, 0, layer._w, layer._h)
        img = self.filter("CICrop", img, {"inputRectangle" : v})  

        return img 
 
    def render_filter_bloom(self, layer, img, options):
        
        # Apply the Core Image Bloom filter effect
        # which adds a hazy glow to the layer
        # by softening edges.
        
        (x,y), (w,h) = img.extent()
        
        r = options["radius"]
        i = options["intensity"]
        
        r = max(0, min(r, 100))
        i = max(0.0, min(i, 1.0))
        p = {"inputRadius": r, "inputIntensity": i}
        img = self.filter(self.FILTER_BLOOM, img, p)
        
        return img        

    def render_filter_spotlight(self, layer, img, options):
        
        # Apply the Core Image Bloom Spotlight effect
        # which adds lighting to the layer.
        # This complex filter has a helper to provide visual feedback.
        
        # The light source is positioned at dx0, dy0, dz0 measured
        # from the layer's center.
        # The light shines in the direction of dx1, dy1.
        
        (x,y), (w,h) = img.extent()
        
        dx0 = options["dx0"] + w/2
        dy0 = options["dy0"]
        dz0 = options["dz0"]
        dx1 = options["dx1"] + w/2
        dy1 = options["dy1"]
        b = options["brightness"]
        n = options["concentration"]
        c = options["color"]
        
        dy0 = h/2 - dy0
        dy1 = h/2 - dy1
        dz0 = max(10, min(dz0, 1000))
        dz1 = 0
        b = max(0.0, min(b, 10.0))
        n = max(0.0, min(n, 1.0)) * 0.1
        p = {
            "inputLightPosition" : CIVector.vectorWithX_Y_Z_(dx0, dy0, dz0),
            "inputLightPointsAt" : CIVector.vectorWithX_Y_Z_(dx1, dy1, dz1),
            "inputBrightness"    : b,
            "inputConcentration" : n,
        }
        if c != None: 
            p["inputColor"] = CIColor.colorWithRed_green_blue_alpha_(c.r, c.g, c.b, c.a)
        img = self.filter(self.FILTER_SPOTLIGHT, img, p)

        # Pass the unmodified parameters so the helper
        # can decide its relative position for itself.
        
        if options["helper"] == True and self.helper != None:
            self.helper.spotlight(layer, w, h, dx0-w/2, h/2+dy0, dz0, dx1-w/2,h/2+dy1, dz1, b, n)
        
        return img

    def render_filter_shadedmaterial(self, layer, img, options):
 
        # Apply the Core Image Shaded Material effect
        # which adds texturing to the layer.
        
        # Without the texture parameter,
        # transforms the layer to a height field mask:
        # the white area becomes a gradient with black at the edges.
        # When the texture parameter is a Canvas,
        # shades that canvas on the height field.
        
        (x,y), (w,h) = img.extent()
        
        r = options["radius"]
        dx = options["dx"]
        dy = options["dy"]
        c = options["texture"]
        
        r = max(0, min(r, 300))
        p = {"inputRadius": r}
        img = self.filter("CIHeightFieldFromMask", img, p)
        
        if isinstance(c, Canvas):

            dx = max(-c.w/2, min(dx, c.w/2))
            dy = max(-c.h/2, min(dy, c.h/2))
            c = self.merge(c)
            
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(dx, dy)
            c = self.filter("CIAffineTransform", c, {"inputTransform": t})
            p = {"inputShadingImage": c, "inputScale": 1.0}
            img = self.filter("CIShadedMaterial", img, p)
        
        v = CIVector.vectorWithX_Y_Z_W_(x, y, w, h)
        img = self.filter("CICrop", img, {"inputRectangle" : v})  
    
        return img
    
    def render_transforms(self, layer, img):
        
        """ Render layer transformations.
        
        By default a top-left coordinate system is emulated.
        Scaling is handled first to avoid distortion when rotating.
        The layer scales and rotates from its origin point.
        
        """

        img = self.render_transform_flip(layer, img)    
        img = self.render_transform_distort(layer, img)
        img = self.render_transform_scale(layer, img)
        img = self.render_transform_rotate(layer, img)
        img = self.render_transform_translate(layer, img)
    
        return img 
    
    def render_transform_flip(self, layer, img):

        flip_h, flip_v = layer._flip
        
        if flip_h == True \
        or flip_v == True:
            
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(layer._w*0.5, layer._h*0.5)
            if flip_h == True: t.scaleXBy_yBy_(-1, 1)
            if flip_v == True: t.scaleXBy_yBy_(1, -1)
            t.translateXBy_yBy_(-layer._w*0.5, -layer._h*0.5)
            img = self.filter("CIAffineTransform", img, {"inputTransform": t})
            
        return img
        
    def render_transform_distort(self, layer, img):

        # Distort doesn't work very well with filters.
        # Example: when applying a blur, the blur overflow at the edges
        # will not originate from the center, causing the image to displace.
        # img.extent() reports wrong bounds.

        (x,y), (w,h) = img.extent()
        
        l, t, r, b = layer.bounds()
        ox = ((w-x) - layer._w) / 2
        oy = ((h-y) - layer._h) / 2
        
        distorted = False
        for pt in layer._distort:
            if pt.x != 0.0 or pt.y != 0.0:
                distorted = True
                break

        if distorted == True:
            p = {"inputTopLeft": 0, "inputTopRight": 1, "inputBottomLeft": 3, "inputBottomRight": 2}
            for k in p.keys():
                i = p[k]
                dx =  layer._distort[i].x * w
                dy = -layer._distort[i].y * h
                if i == 1 or i == 2: dx += w
                if i == 0 or i == 1: dy += h
                p[k] = CIVector.vectorWithX_Y_(dx-ox/0.8, dy-oy/2)

            img = self.filter("CIPerspectiveTransform", img, p)
        
        return img

    def render_transform_scale(self, layer, img):

        if layer._scale.x != 1.0 \
        or layer._scale.y != 1.0:
            
            dx = layer._w*0.5 * layer._origin.x
            dy = layer._h*0.5 * (1-layer._origin.y)
                
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(dx * layer._scale.x, dy * layer._scale.y)
            t.scaleXBy_yBy_(layer._scale.x, layer._scale.y)        
            t.translateXBy_yBy_(-dx, -dy)
            img = self.filter("CIAffineTransform", img, {"inputTransform": t})
        
        return img

    def render_transform_rotate(self, layer, img):

        if layer.rotation % 360 != 0:
            
            dx = layer._w * layer._scale.x * layer._origin.x
            dy = layer._h * layer._scale.y * (1-layer._origin.y)
                
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(dx, dy)
            t.rotateByDegrees_(-layer.rotation)
            t.translateXBy_yBy_(-dx, -dy)
            img = self.filter("CIAffineTransform", img, {"inputTransform": t})
        
        return img
        
    def render_transform_translate(self, layer, img, topleft=True):
        
        dx = layer._w * layer._scale.x * layer._origin.x
        dy = layer._h * layer._scale.y * (1-layer._origin.y)
        
        t = NSAffineTransform.transform()
        t.translateXBy_yBy_(layer.x, layer.canvas.h-layer.y)
        t.translateXBy_yBy_(-dx, -dy)
        img = self.filter("CIAffineTransform", img, {"inputTransform": t})
        
        return img
    
    def render_mask(self, layer, img):
        
        """ Render the layer mask.
        
        Returns the layer with its alpha mask applied.
        A mask makes the layer shine through where it is darker.
        
        """
        
        mask = None
        
        if isinstance(layer.mask, Canvas) \
        and len(layer.mask.layers) > 0:
            mask = self.merge(layer.mask)
            
        if mask != None:
            (x, y), (w, h) = img.extent()
            transparent = self.image(LAYER_FILL, Transparent(), w, h)
            p = {"inputBackgroundImage": transparent, "inputMaskImage": mask}
            img = self.filter("CIBlendWithMask", img, p)
        
        return img
    
    def render_opacity(self, layer, img):
        
        """ Render layer blending.
        
        Apply its global transparency
        and composite the layer with the layer below
        using the appropriate blending mode.
            
        """
            
        if layer.opacity < 1.0:
            a = max(0.0, min(layer.opacity, 1.0))
            v = CIVector.vectorWithX_Y_Z_W_(0, 0, 0, a)
            img = self.filter("CIColorMatrix", img, {"inputAVector": v})
            
        return img
    
    def render(self, layer):
        
        """ Renders a single layer.
        
        Apply filters, transforms, mask and opacity.
        The actual layer compositing (blending)
        is done in merge().
        
        """
        
        img = self.image(layer.type, layer.data, layer._w, layer._h)
        
        if layer.filters_first() == True:
            img = self.render_filters(layer, img)

        img = self.render_adjustments(layer, img)
        img = self.render_mask(layer, img)
        img = self.render_opacity(layer, img)        
        img = self.render_transforms(layer, img)

        if layer.filters_first() == False:
            img = self.render_filters(layer, img)
            
        return img
    
    def merge(self, canvas, layers=[]):
        
        """ Flattens the canvas into a single CIImage.
        
        Composites the layers in the given canvas
        by rendering them individually and then blending them.
        The optional layers list specifies which layers
        from the canvas to render (all by default).
        
        """
        
        w = canvas.w
        h = canvas.h
        
        # All of the layers are rendered
        # against a transparent canvas background.
        
        base = self.image(LAYER_FILL, Transparent(), w, h)

        # Determine which layers to render:
        # hidden layers don't need to be processed.
        # If the layers list is not empty,
        # render only layers that are in it.

        layers_to_render = []
        if len(layers) == 0:
            layers = canvas.layers
        for layer in layers:
            if layer.hidden == False: 
                layers_to_render.append(layer)

        for layer in layers_to_render:
            
            img = self.render(layer)

            # Crop the layer to the bounds of the canvas.

            v = CIVector.vectorWithX_Y_Z_W_(0, 0, w, h)
            img = self.filter("CICrop", img, {"inputRectangle" : v})         
            
            if layer.blendmode == BLEND_NORMAL:                
                base = self.filter("CISourceOverCompositing", img, 
                       parameters={"inputBackgroundImage": base})
            if layer.blendmode == BLEND_MULTIPLY:  
                base = self.filter("CIMultiplyBlendMode", img, 
                       parameters={"inputBackgroundImage": base})
            if layer.blendmode == BLEND_SCREEN:  
                base = self.filter("CIScreenBlendMode", img, 
                       parameters={"inputBackgroundImage": base})
            if layer.blendmode == BLEND_OVERLAY:  
                base = self.filter("CIOverlayBlendMode", img, 
                       parameters={"inputBackgroundImage": base})
            if layer.blendmode == BLEND_SOFTLIGHT:  
                base = self.filter("CISoftLightBlendMode", img, 
                       parameters={"inputBackgroundImage": base})
            if layer.blendmode == BLEND_HARDLIGHT:
                base = self.filter("CIHardLightBlendMode", img, 
                       parameters={"inputBackgroundImage": base})
            if layer.blendmode == BLEND_HUE:  
                base = self.filter("CIHueBlendMode", img, 
                       parameters={"inputBackgroundImage": base})
            if layer.blendmode == BLEND_COLOR:  
                base = self.filter("CIColorBlendMode", img, 
                       parameters={"inputBackgroundImage": base})
 
        # The result is one CIImage
        # which contains a flattened image of the layers.
       
        return base
    
    def draw(self, canvas, x, y, layers=[], helper=False):

        """ Draws the flattened image of the canvas to NodeBox.
        
        The output of the canvas is drawn at x and y.
        If the renderer was unable to produce output in NodeBox,
        raises a CanvasToNodeBoxError.
        
        It's very easy to modify this code to have Core Image
        draw somewhere else than in NodeBox: don't append _draw()
        to the NodeBox scenegraph but use update_graphicscontext()
        directly with a flattened canvas to update 
        the NSGraphicsContext.
        
        The resulting image in NodeBox has pixel errors when
        you export it to PDF, likely because it is in RGB and
        contains transparency. When exporting PDf you should
        export a CMYK TIFF and draw that with the NodeBox image() command.
        
        """

        w = canvas.w
        h = canvas.h
        flattened = self.merge(canvas, layers)
        
        try:
            self._cache = (x, y, w, h, flattened)
            _ctx._canvas.append(self._draw)

        except:
            raise CanvasToNodeBoxError

        if helper == True:
            self.helper.rulers(x, y, w, h)
            if layers == []: layers = canvas.layers
            self.helper.guides(x, y, w, h, layers)

    def _draw(self):
        
        # Before drawing into the current graphics context,
        # inherit the NodeBox transformation state.
        # Resolve center mode transforms.
        
        from DrawingPrimitives import CENTER
        
        x, y, w, h, flattened = self._cache

        NSGraphicsContext.currentContext().saveGraphicsState()
        
        if _ctx._transformmode == CENTER:
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(x+w/2, y+h/2)
            t.concat()
        
        t = NSAffineTransform.transform()
        t.scaleXBy_yBy_(1, -1) #flip
        t.concat()
  
        state = _ctx._transform.copy()
        state.concat()    
        
        if _ctx._transformmode == CENTER:
            t = NSAffineTransform.transform()
            t.translateXBy_yBy_(-x-w/2, -y-h/2)
            t.concat()
        
        self.update_graphicscontext(flattened, x, y, w, h)
        
        NSGraphicsContext.currentContext().restoreGraphicsState()
        
        if self.helper != None:
            self.helper.draw()
        
    def update_graphicscontext(self, img, x, y, w, h):
        
        # Very sweet: draw the flattened CIImage in a CIContext
        # from the current context to take full advantage of Core Image.
        
        ctx = NSGraphicsContext.currentContext().CIContext()
        ctx.drawImage_atPoint_fromRect_(img, (x,y), ((0,0),(w,h)))
    
    def export(self, canvas, name, type=FILE_PNG, compression=None, cmyk=False, layers=[]):
        
        """ Exports a flattened composition as a file.
        
        Merges all of the layers and export that image to file.
        You can choose between a FILE_GIF,
        a FILE_PNG with transparent background,
        a FILE_JPEG with white background and (optional) compression,
        a FILE_TIFF with transparent background and(optional) LZW-compression.
        
        When exporting to TIFF you can choose to convert it to CMYK.
        Currently LZW is not supported for CMYK TIFF.
        
        """
        
        w = canvas.w
        h = canvas.h           
        flattened = self.merge(canvas, layers)

        # Some Cocoa type juggling.
        # A CIImage does not remember actual pixel data.
        # We need to create a "real" NSImage from it.
        # The TIFF data from the NSImage we can then cast
        # into some other file format.

        img = NSImage.alloc().initWithSize_((w, h))
        #img.setFlipped_(True)
        img.addRepresentation_(NSCIImageRep.imageRepWithCIImage_(flattened))
        img = img.TIFFRepresentation()
        img = NSBitmapImageRep.imageRepWithData_(img)
        
        options = None
        if type == FILE_GIF:
            type = NSGIFFileType
            ext = ".gif"
        if type == FILE_PNG:
            type = NSPNGFileType
            ext = ".png"
        if type == FILE_JPEG:
            type = NSJPEGFileType
            ext = ".jpg"
            if isinstance(compression, float):
                options = {NSImageCompressionFactor: max(0.0, min(compression, 1.0))}
        if type == FILE_TIFF:
            type = NSTIFFFileType
            ext = ".tif"
            if compression == True and cmyk == False:
                options = {NSImageCompressionMethod:NSTIFFCompressionLZW}
        
        data = img.representationUsingType_properties_(type, options)
        f = open(name+ext, "w")
        f.write(data.bytes())
        f.close()
        
        if type == NSTIFFFileType and cmyk == True:
            self.convert_tif_cmyk(name+ext)
        
    def convert_tif_cmyk(self, path):
        
        """ Converts a TIFF file to CMYK.
        
        Converts the TIFF's colorspace to CMYK using Core Graphics.
        Resulting files are currently uncompressed.
        Also, a generic CMYK profile is used.
        This means that the renderer makes no attempt to correctly remap colors
        that are outside the CMYK scope: pure RGB red and other high intensity
        colors may contain pixel errors. This is especially true for paths
        and it is your responsibility to create paths in CMYK-safe colors.
        
        """
        
        w, h = self.imagesize(path)
        cs = CGColorSpaceCreateWithName(kCGColorSpaceGenericCMYK)
        bg = (1.0,1.0,1.0,1.0)
        gc = CGBitmapContextCreateWithColor(int(w), int(h), cs, bg)
        im = CGImageImport(CGDataProviderCreateWithFilename(path))
        gc.drawImage(CGRectMake(0,0,w,h), im)
        gc.writeToFile(path, kCGImageFormatTIFF)

### COREIMAGEPIXELS ##################################################################################

import Numeric
class CoreImagePixels:
    
    def __init__(self, renderer, layer, img):

        """ The Pixels class provides pixel-based information for CIImage objects.
        
        Creates a pixel array for a CIImage object,
        using Numeric for faster array processing.
        The pixels values are assumed to be RGB
        and range between 0 and 255.
        
        Acquiring pixel information may take some time to process.
        
        At this point Pixels is only for retrieving
        and not for setting pixels.
        
        """

        self.renderer = renderer
        self.layer = layer

        (self.x, self.y), (self.w, self.h) = img.extent()
        self.w = int(self.w)
        self.h = int(self.h)

        self._img = NSImage.alloc().initWithSize_((self.w, self.h))
        self._img.addRepresentation_(NSCIImageRep.imageRepWithCIImage_(img))
        self._img = self._img.TIFFRepresentation()
        self._img = NSBitmapImageRep.imageRepWithData_(self._img)
        
        raw = self._img.bitmapData()
        a = Numeric.fromstring(raw, Numeric.UnsignedInt8)
        
        self.channels = self._img.samplesPerPixel()
        self.pixels = Numeric.reshape(a, (self.w*self.h, self.channels))
        
        if self.is_rgb():
            self.r = self.pixels[:,0] 
            self.g = self.pixels[:,1]
            self.b = self.pixels[:,2]
            self.a = None
            if self.has_alpha(): self.a = self. pixels[:,3]
    
    def is_rgb(self):
        
        return self._img.colorSpaceName().find("RGB") >= 0
    
    def has_alpha(self):
        
        return (self._img.hasAlpha() == 1)
        
    def get_pixel(self, x, y):
        
        """ Returns color values for the pixel at x, y.
        """
        
        if 0 <= x < self.w and 0 <= y < self.h:
            return list(self.pixels[x+y*self.w])
        else:
            return None
    
    def min(self, transparency=False, treshold=0):
        
        """ Returns the lowest color values in the image.
        
        By default, transparent pixels (alpha=0) are
        not searched. The treshold defines the cutoff,
        for example treshold=100 means that all pixels with alpha
        less than 100 are not taken into account.
        
        """

        a = self.pixels.astype(Numeric.UnsignedInt32)
        if transparency == False and self.has_alpha():
            i = Numeric.nonzero(Numeric.greater(self.a, treshold))
            a = Numeric.take(a, i)
        
        i = Numeric.argmin(a, 0)
        v = []
        for j in range(self.channels):
            v.append(a[i[j]][j])
        return v
    
    def max(self, transparency=False, treshold=0):

        """ Returns the highest color values in the image.
        """

        a = self.pixels.astype(Numeric.UnsignedInt32)
        if transparency == False and self.has_alpha():
            i = Numeric.nonzero(Numeric.greater(self.a, treshold))
            a = Numeric.take(a, i)
        
        i = Numeric.argmax(a, 0)
        v = []
        for j in range(self.channels):
            v.append(a[i[j]][j])
        return v
        
    def average(self, transparency=False, treshold=0):
        
        """ Returns the average color values in the image.
        """
        
        a = self.pixels.astype(Numeric.UnsignedInt32)
        n = len(self.pixels)
        
        if transparency == False and self.has_alpha():
            i = Numeric.nonzero(Numeric.greater(self.a, treshold))
            a = Numeric.take(a, i)
            n = len(i)
        
        a = Numeric.sum(a) / n
        
        v = []
        for i in range(self.channels):
            v.append(int(a[i]))
        return v
        
    def histogram(self, channel=None, helper=False):
        
        """ Computes a histogram for the image.
        
        A histogram is a list for each color channel.
        Each color list has indices from 0 to 255,
        and lists the occurence of each of those color values
        as a percentage between 0.0 and 1.0
        
        """
        
        bins = Numeric.arange(1, 255, 1)
        v = []
        for i in range(self.channels):
            p = self.pixels[:,i]
        
            # From the NumPy searchsorted() documentation.
            
            n = Numeric.searchsorted(Numeric.sort(p), bins)
            n = Numeric.concatenate([n, [len(p)]])
            n = n[1:]-n[:-1]
            
            # Make the values in the histogram percentual
            # by dividing each by the highest.
            
            n = n.astype(Numeric.Float)
            n = n / n[Numeric.argmax(n)]
            v.append(n)
        
        if helper == True and self.renderer.helper != None:
            self.renderer.helper.histogram(v, self.layer.x, self.layer.y)
            
        return v

### COREIMAGEHELPER ##################################################################################

from math import sqrt, pow
from math import sin, cos, atan, pi, radians, degrees 
class CoreImageHelper:
    
    """ Provides visual feedback in NodeBox on certain filters.
    
    Usually the helper is only useful when the layer is
    transformed by that single filter. If you furthermore
    transform and filter the layer the helper will not
    display at the correct position.
    
    Invoking a helper is usually as simple as setting
    the helper=True in the filter parameters.
    
    """
    
    def __init__(self, renderer):
        
        self.renderer = renderer
        self.background = (0.0, 0.0, 0.0, 0.5)
        self.foreground = (1.0, 1.0, 1.0, 0.5)
        self.roundness = 0.0
        self.font = "Arial"
        self.fontsize = 8.5
        
        self._stack = {}
        self._i = 1
    
    def interface(self, filter):
        
        """ Interfaces parameters for the filter to NodeBox sliders.
        """
        
        from DrawingPrimitives import BOOLEAN, NUMBER
        
        vars = {}
 
        # Use the short alias as display name
        # and provide a render yes/no checkbox.
        
        name = filter
        for alias in self.renderer.aliases:
            if self.renderer.aliases[alias] == filter:
                name = alias     
                break
        name = str(self._i) + "_" +  name
        _ctx.var(name, BOOLEAN, True)
        try: vars["render"] = _ctx.findvar(name).value
        except: vars["render"] = True
        
        # For each parameter,
        # find the defaults in the corresponding CIFilter.
        
        f = CIFilter.filterWithName_(filter)
        a = f.attributes().items()
        for param in self.renderer.filters[filter]:
            
            n = param + "_" + str(self._i)
            value = self.renderer.filters[filter][param]
            vars[param] = value
 
            if param == "helper":
                _ctx.var(n, BOOLEAN, False)
                try: vars[param] = _ctx.findvar(n).value
                except: vars[param] = False
            
            if isinstance(value, (int, float)) \
            and param != "interface" \
            and param != "helper":
            
                min = -600.0
                max =  600.0
                if param == "dx" or param == "dy":
                    min = -1000
                    max =  1000
                elif param in "rgba":
                    min = 0.0
                    max = 1.0
                else:  
                    for key, attr in a:
                        if key.lower().find(param) >= 0:
                            min = attr['CIAttributeSliderMin']
                            max = attr['CIAttributeSliderMax']
                            if param == "angle":
                                min = min / 3.14 * 360
                                max = max / 3.14 * 360
                            break
                
                _ctx.var(n, NUMBER, value, min, max)
                try: vars[param] = _ctx.findvar(n).value
                except: vars[param] = value
        
        self._i += 1 
        return vars

    def draw(self):
        
        """ Draws all the defined helpers.
        
        This command is called from the renderer
        once the merged canvas has been drawn in NodeBox.
        
        """
        
        if isinstance(self.background, tuple):
            r,g,b,a = self.background
            self.background = _ctx.color(r,g,b,a)
            r,g,b,a = self.foreground
            self.foreground = _ctx.color(r,g,b,a)
        
        for f in self._stack:
            args = self._stack[f]
            f = getattr(self, "_"+f)
            f(args)
            
        self._stack = {}
    
    def rulers(self, x, y, w, h):
        
        """ Helper that draws canvas rulers.
        """
        
        self._stack["rulers"] = (x, y, w, h)
    
    def _rulers(self, args):
        
        x, y, w, h = args
        
        rw = 3 * 10
        _ctx.nostroke()
        _ctx.fill(self.background)
        _ctx.rect(x, y, rw, h)
        _ctx.rect(x+rw, y, w-rw, rw)
        
        _ctx.fill(self.foreground)
        _ctx.stroke(self.foreground)
        _ctx.strokewidth(0.5)
        _ctx.font(self.font, self.fontsize)
        d = 10
        n = (h-rw)/d
        
        for i in range(n):
            if (i+3) % 5 == 0:
                _ctx.text(str((i+3)*d), x+2, rw+i*d-2)
                _ctx.stroke(1.0)
            _ctx.line(x, rw+i*d, x+rw, rw+i*d)
            _ctx.stroke(self.foreground)

        n = (w-rw)/d
        for i in range(n):
            if (i+3) % 5 == 0:
                _ctx.stroke(1.0)
            _ctx.line(rw+i*d, y, rw+i*d, y+rw)
            _ctx.stroke(self.foreground)
    
    def guides(self, x, y, w, h, layers):
        
        """ Helper that draws layer bounds and origin.
        """
        
        self._stack["guides"] = (x, y, w, h, layers)
            
    def _guides(self, args):
        
        x, y, w, h, layers = args
        
        for layer in layers:
        
            l, t, r, b = layer.bounds()
            _ctx.nofill()
            _ctx.stroke(self.foreground)
            _ctx.strokewidth(0.5)
            _ctx.rect(l, t, r-l, b-t)
        
            r = 10
            _ctx.fill(self.background)
            _ctx.oval(layer.x-r/2, layer.y-r/2, r, r)
            _ctx.line(layer.x, y, layer.x, h)
            _ctx.line(x, layer.y, w, layer.y)
    
    def histogram(self, h, x, y):
        
        """ Helper for the Layer.pixels().histogram command.
        """
        
        self._stack["histogram"] = (h, x, y)
        
    def _histogram(self, args):
        
        h, x, y = args
        
        x += 5
        y += 5
        dh = 30
        dw = 0.5
        
        _ctx.nostroke()
        _ctx.fill(self.background)
        _ctx.rect(x, y, 30+255*dw, 20+len(h)*(dh+10), roundness=self.roundness)
        
        x += 15
        y += 15
        for channel in h:
            _ctx.stroke(self.foreground)
            _ctx.strokewidth(0.75)
            _ctx.line(x, y+dh, x+255*dw, y+dh)
            for i in range(len(channel)):
                _ctx.line(x+i*dw, y+dh, x+i*dw, y+dh-channel[i]*dh)
            y += dh+10
            
    def spotlight(self, layer, w, h, dx0, dy0, dz0, dx1, dy1, dz1, brightness, concentration):
        
        """ Helper for the Layer.filter(name="lighting") command.
        """
        
        self._stack["spotlight"] = (layer, w, h, dx0, dy0, dz0, dx1, dy1, dz1, brightness, concentration) 

    def _spotlight(self, args):

        layer, w, h, dx0, dy0, dz0, dx1, dy1, dz1, brightness, concentration = args
        l, t, r, b = layer.bounds()

        from DrawingPrimitives import CORNER, CENTER

        # Draw the helper relative to
        # the layer's position.
        # Layer scaling, rotation, etc. are not processed.
        
        dx0 += l+(r-l)/2
        dy0 -= t+(b-t)/2
        dx1 += l+(r-l)/2
        dy1 -= t+(b-t)/2
        
        _ctx.stroke(self.foreground)
        _ctx.strokewidth(0.5)
        _ctx.fill(self.background)
        
        # Spotlight position
        
        r = 20
        vx0 = dx0
        vy0 = h - dy0
        _ctx.oval(vx0-r/2, vy0-r/2, r, r)

        _ctx.fill(self.background)
        f = _ctx.fill()
        f.a /= 2
        _ctx.fill(f)
        r = 10
        vx1 = dx1
        vy1 = h - dy1
 
        # Light concentration radius
        
        dr = concentration*8000 * (1+0.025/concentration)
        _ctx.oval(vx1-dr/2, vy1-dr/2, dr, dr)
        
        # Light direction
        _ctx.oval(vx1-r/2, vy1-r/2, r, r)
        _ctx.line(vx0, vy0, vx1, vy1)    

        # Light spread based on source height.
        
        spread = 10 + dz0/10
        a = self._angle(vx0, vy0, vx1, vy1)
        n = self._distance(vx0, vy0, vx1, vy1) + dz0
        _ctx.transform(CORNER)
        _ctx.push()
        _ctx.translate(vx0, vy0)
        _ctx.rotate(a-spread)
        _ctx.line(0, 0, n, 0)
        _ctx.pop()
        _ctx.push()
        _ctx.translate(vx0, vy0)
        _ctx.rotate(a+spread)
        _ctx.line(0, 0, n, 0)
        _ctx.pop()  
        _ctx.transform(CENTER)

    def _distance(self, x0, y0, x1, y1):
        
        return sqrt(pow(x1-x0, 2) + pow(y1-y0, 2))
        
    def _angle(self, x0, y0, x1, y1):
        
        a = degrees( atan((y1-y0) / (x1-x0+0.00001)) ) + 360
        if x1-x0 < 0: a += 180
        return 360 - a

#### COMMANDS ########################################################################################
    
def color(r=None, g=None, b=None, a=None):
    return Color(r, g, b, a)
    
def transparent():
    return Transparent()

def canvas(w, h, renderer=CoreImageRenderer()):
    return Canvas(w, h, renderer)