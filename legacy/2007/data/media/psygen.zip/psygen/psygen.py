from random import seed
size(600, 600)


# First download the Core Image library from http://nodebox.net
# Put coreimage.py and morguefile.py in 
# the same folder as this script.
coreimage = ximport("coreimage")
morguefile = ximport("morguefile")

# What images are we looking for?
queries = ( "CHURCH", "JESUS")
#query = choice()

# Download some images from morguefile.com
# The script will create a folder and put
# the downloaded images in it.
# Next time we will take images from this folder
# instead of downloading them again.
for query in queries:
    if len(files(query+"/*")) == 0:
        # Search for 30 images...
        images = morguefile.query(query, max=30)
        # Shuffle the list...
        from random import shuffle
        shuffle(images)
        for img in images[:5]:
            morguefile.download(img, query+"/")

# Draw a dark grey background
fill(0.1)
rect(0,0,WIDTH,HEIGHT)

# Create a layered canvas in which we can
# composit and manipulate layers.
canvas = coreimage.canvas(600, 600)

# Create 10 random layers.
# Remember, it may take a few seconds to load
# all the images during the first run.
for i in range(15):
    
    # Create a layer from a random image in the folder.
    img = choice(files(choice(queries)+"/*"))
    l = canvas.layer(img)
    
    # Give each layer a gradient mask.
    #l.mask.layer_radial_gradient()
    
    # Put the layer at a random location on the canvas.
    l.x = random(canvas.w)
    l.y = random(canvas.h)
    
    # Some random rotation and scaling.
    l.rotate(random(346))
    l.scale(random(0.1, 1.94))
    #l.invert()
    
    # Randomly apply kaleidoscopic, twirl and bump effects.
    #if random() > 0.75:
    #    l.filter_kaleidoscope()
    #if random() > 0.25:
    radius = 96.67
    twirl = 86.58
    l.filter_twirl(radius=370, angle=random(-360, 360))
    #if random() > 0.25:
    #    l.filter_bumpdistortion()
    #if random() > 0.5:
    #    l.blend_multiply()
    l.adjust_contrast(1.46)
    #l.blend(113, mode="multiply")
    l.distort(dy0=random(-71, 200), dx2=random(-200, 200))
    l.fitler_bloom(intensity=2.09)
    #l.filter_shading(radus=-0.23, dx=-127)
    #l.desaturate()
    #l.filter_levels(r=0.56, b=1.12, g=-2.28)
    l.blend(opacity=random(), mode=choice(('multiply', 'screen', 'normal')))
    #l.filter_sharpen(amount=10)
    #l.filter_zoomblur(dx=25, amount=10)

#l = canvas.layer_fill(color(0,1.01,0))
#l.blend_color(opacity=0.1)
#l.blend(274, mode="color")
#l.blend(50)

# Draw to NodeBox!
canvas.draw(0,0)