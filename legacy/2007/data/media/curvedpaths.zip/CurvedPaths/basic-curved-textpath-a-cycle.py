size(400, 400)
background(1, 0,0)
from math import pi, sqrt, sin, cos, asin, atan2

def calc_angle(x1, y1, x2, y2):
    return atan2(x2-x1, y2-y1)

def calc_point(x, y, a, distance):
    return x + cos(a) * distance, y + sin(a) * distance

def calc_dist(x1, y1, x2, y2):
    return sqrt(pow(x2-x1, 2) + pow(y2-y1, 2))

def angle(x0, y0, x1, y1):
    from math import degrees, atan
    a = degrees( atan((y1-y0) / (x1-x0+0.00001)) ) + 360
    if x1-x0 < 0: a += 180
    return a
    
def coordinates(x0, y0, distance, angle):
    from math import radians, sin, cos
    x1 = x0 + cos(radians(angle)) * distance
    y1 = y0 + sin(radians(angle)) * distance
    return x1, y1

def relative_point(points, index, rel):
    pos = min(max(index+rel, 0), len(points)-1)
    return points[pos]

def create_curved_path(source_path, split_count=12, max_delta=14):
    
    split_points = []

    source_points = list(source_path.points(int(split_count)))
    source_points.append(source_path.point(1.0))
    for i, pt in enumerate(source_points):
        oval(pt.x-2, pt.y-2,4,4)
        prev_pt = relative_point(source_points, i, -1)
        next_pt = relative_point(source_points, i, 1)
        a = calc_angle(prev_pt.x, prev_pt.y, next_pt.x, next_pt.y)
        #a -= pi/2.0
        d = sin((FRAME/10.0)+i/2.86) * max_delta # random(-max_delta, max_delta)
        x2, y2 = calc_point(pt.x, pt.y, a, d)
        line(pt.x, pt.y, x2, y2)
        #pt.x = x2
        #pt.y = y2
        fill(0)
        oval(x2-2, y2-2, 4 , 4)
        nofill()
        split_points.append(Point(x2, y2))
    
    curved_path = findpath(split_points)
    return curved_path
    
FRAME=100
autoclosepath(False)
stroke(0)
nofill()
#p = line(100, 100, 226, 313)
fontsize(408)
fill(0,0,0,0.41)
tp = textpath("A", 66, 338)
p = tp.contours[1]

d = sin(pi * FRAME / 100.0) * 23.0

newp = create_curved_path(p, p.length/10, d)
fill(1,0.56)
newp.inheritFromContext()
newp.draw()

p = tp.contours[0]
newp = create_curved_path(p, p.length/10, d)
fill(0,0.56)
newp.inheritFromContext()
newp.draw()