bezier = ximport("bezier")

# Some cold blue colors.
background(0.8,0.9,1)

# Draw random blue stars for a pointy, snowy atmosphere.
for i in range(60):
    fill(0,0.5,random(0.5,0.75),0.1 * 0.02*i)
    rotate(random(360))
    star(random(WIDTH/2), random(50+HEIGHT/4), random(10,60), 100, random(200))
    # ... once you understand the code below,
    # you'll realise that since stars are paths
    # we could grow icicles on the stars as well.
reset()

fill(0,0,0,0.1)
stroke(1)
strokewidth(0.75)

font("Arial-Black", 160)
baseline = 250
# An outlined text path which we can transform.
# Notice how it is positioned on a baseline,
# we need the location of the baseline later on.
p = textpath("COLD", 50, baseline)

# Chop the text path into a list of separate contours.
for contour in bezier.contours(p):
        
    n = 100
    first = True
    s = bezier.length(contour, segmented=True)
    for i in range(n):
        
        # For each contour, get the coordinates of a 100 points
        # on its stroke outline.
        pt = bezier.point(contour, float(i)/n, segments=s)
        if first:
            beginpath(pt.x, pt.y)
            first = False
        else:
            # If a point on the contour is in the lower half
            # of the font height,
            # add sharp downward strokes.
            if pt.y > baseline-fontsize()/2:
                lineto(pt.x+random(-10,10), pt.y+random(-10,60))
                lineto(pt.x+random(-10,10), pt.y+random(-10,10))
            lineto(pt.x, pt.y)
    
    p = endpath()