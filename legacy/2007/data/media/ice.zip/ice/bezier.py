# Bezier - last updated for NodeBox 1rc4 
# Author: Tom De Smedt <tomdesmedt@trapdoor.be>
# Manual: http://nodebox.net/code/index.php/Bezier
# Copyright (c) 2006 by Tom De Smedt.
# Refer to the "Use" section on http://nodebox.net/code/index.php/Use
# Thanks to Dr. Florimond De Smedt at the Free University of Brussels for the math routines.

# XXX - this stuff should be in the context by default
from DrawingPrimitives import PathElement, Point, MOVETO, LINETO, CURVETO, CLOSE
    
def _linepoint(t, x0, y0, x1, y1):

    """Returns coordinates for point at t on the line.

    Calculates the coordinates of x and y for a point
    at t on a straight line.

    The t parameter is a number between 0.0 and 1.0,
    x0 and y0 define the starting point of the line,
    x1 and y1 the ending point of the line,    

    """

    xt = x0 + t * (x1-x0)
    yt = y0 + t * (y1-y0)

    p = PathElement()
    p.cmd = LINETO
    p.x = p.ctrl1.x = p.ctrl2.x = xt
    p.y = p.ctrl1.y = p.ctrl2.y = yt
    return p

def _linelength(x0, y0, x1, y1):

    """Returns the length of the line.
    """
           
    from math import sqrt, pow

    a = pow(abs(x0 - x1), 2)
    b = pow(abs(y0 - y1), 2)
    c = sqrt(a+b)
    return c

def _curvepoint(t, x0, y0, x1, y1, x2, y2, x3, y3, handles=False):

    """Returns coordinates for point at t on the spline.

    Calculates the coordinates of x and y for a point
    at t on the cubic bezier spline, and its control points,
    based on the de Casteljau interpolation algorithm.

    The t parameter is a number between 0.0 and 1.0,
    x0 and y0 define the starting point of the spline,
    x1 and y1 its control point,
    x3 and y3 the ending point of the spline,
    x2 and y2 its control point.
    
    If the handles parameter is set,
    returns not only the point at t,
    but the modified control points of p0 and p3
    should this point split the path as well.

    """
    
    x01   = x0 * (1-t) + x1 * t
    y01   = y0 * (1-t) + y1 * t
    x12   = x1 * (1-t) + x2 * t
    y12   = y1 * (1-t) + y2 * t
    x23   = x2 * (1-t) + x3 * t
    y23   = y2 * (1-t) + y3 * t
   
    p = PathElement()
    p.cmd = CURVETO
    p.ctrl1.x = x01 * (1-t) + x12 * t
    p.ctrl1.y = y01 * (1-t) + y12 * t
    p.ctrl2.x = x12 * (1-t) + x23 * t
    p.ctrl2.y = y12 * (1-t) + y23 * t
    p.x = p.ctrl1.x * (1-t) + p.ctrl2.x * t
    p.y = p.ctrl1.y * (1-t) + p.ctrl2.y * t

    if handles == False:
        return p
    else:
        return (p, Point(x01,y01), Point(x23,y23))

def _curvelength(x0, y0, x1, y1, x2, y2, x3, y3, n=10):

    """Returns the length of the spline.

    Integrates the estimated length of the cubic bezier spline
    defined by x0, y0, ... x3, y3, by adding the lengths of
    lineair lines between points at t.

    The number of points is defined by n 
    (n=10 would add the lengths of lines between 0.0 and 0.1, 
    between 0.1 and 0.2, and so on).

    The default n=10 is fine for most cases, usually
    resulting in a deviation of less than 0.01.

    """

    from math import sqrt, pow

    length = 0
    xi = x0
    yi = y0

    for i in range(n):
    
        t = 1.0 * (i+1) / n
        p = _curvepoint(t, x0, y0, x1, y1, x2, y2, x3, y3)
        c = sqrt(pow(abs(xi-p.x),2) + pow(abs(yi-p.y),2))
        length += c
        #_ctx.line(xi,yi,p.x,p.y)
        xi = p.x
        yi = p.y
        
    return length
    
def _tuple(point):
    
    """Returns the given PathElement point as a tuple.
    
    Extracting all the values in a point is a recurring operation.
    Meanwhile, solves a bug in NodeBox 1.0rc3,
    where the control points are sometimes stored as tuples, 
    and not as Point objects.
    
    """
    
    from types import TupleType
    if type(point.ctrl1) == TupleType:
        ctrl1x, ctrl1y = point.ctrl1[0], point.ctrl1[1]
        ctrl2x, ctrl2y = point.ctrl2[0], point.ctrl2[1]
    else:
        ctrl1x = point.ctrl1.x
        ctrl1y = point.ctrl1.y
        ctrl2x = point.ctrl2.x
        ctrl2y = point.ctrl2.y
    x = point.x
    y = point.y
    
    return (x, y, ctrl1x, ctrl1y, ctrl2x, ctrl2y) 

def length(path, segmented=False, n=10):

    """Returns the length of the path.

    Calculates the length of each spline in the path,
    using n as a number of points to measure.

    When segmented is True, returns a list
    containing the individual length of each spline
    as values between 0.0 and 1.0,
    defining the percentual length of each spline
    in relation to the total path length.

    """

    length = 0
    segments = []
    first = True

    for point in path:

        if first == True:
            closeto = Point(point.x, point.y)
            first = False
        elif point.cmd == MOVETO:
            closeto = Point(point.x, point.y)
            segments.append(0)
        elif point.cmd == CLOSE:
            c = _linelength(x0, y0, closeto.x, closeto.y)
            segments.append(c)        
        elif point.cmd == LINETO:
            c = _linelength(x0, y0, point.x, point.y)
            segments.append(c)
        elif point.cmd == CURVETO:
            x3, y3, x1, y1, x2, y2 = _tuple(point)
            c = _curvelength(x0, y0, x1, y1, x2, y2, x3, y3, n)
            segments.append(c)
            
        x0 = point.x
        y0 = point.y
    
    for s in segments: length += s
    for i in range(len(segments)):
        try: segments[i] = 1.0 * segments[i] / length
        except ZeroDivisionError: pass
    
    if segmented == False:
        return length
    else:
        return segments
        
def _locate(path, t, segments=None):
    
    """Locates t on a specific segment in the path.
    
    Returns (index, t, PathElement)
    
    A path is a combination of lines and curves (segments).
    The returned index indicates the start of the segment
    that contains point t.
    
    The returned t is the absolute time on that segment,
    in contrast to the relative t on the whole of the path.
    The returned point is the last MOVETO,
    any subsequent CLOSETO after i closes to that point.
    
    """
    
    if segments == None:
        segments = length(path, segmented=True)
    
    for i in range(len(segments)):
        if i == 0 or path[i].cmd == MOVETO:
            closeto = Point(path[i].x, path[i].y)
        if t <= segments[i] or i == len(segments)-1: break
        else: t -= segments[i]

    try: t /= segments[i]
    except: pass
    if i == len(segments)-1 and segments[i] == 0: i -= 1
    
    return (i, t, closeto)

def point(path, t, segments=None):

    """Returns coordinates for point at t on the path.

    Gets the length of the path, based on the length
    of each curve and line in the path.
    Determines in what segment t falls.
    Gets the point on that segment.
    
    When you supply the list of segment lengths yourself,
    as returned from length(path, segmented=True),
    point() works about thirty times faster in a for-loop,
    since it doesn't need to recalculate the length
    during each iteration.

    """

    if len(path) == 0: 
        return None

    i, t, closeto = _locate(path, t, segments=segments)

    x0 = path[i].x
    y0 = path[i].y
    x3, y3, x1, y1, x2, y2 = _tuple(path[i+1])

    if path[i+1].cmd == CLOSE:
        return _linepoint(t, x0, y0, closeto.x, closeto.y)
    if path[i+1].cmd == LINETO:
        return _linepoint(t, x0, y0, x3, y3)
    elif path[i+1].cmd == CURVETO:
        return _curvepoint(t, x0, y0, x1, y1, x2, y2, x3, y3)    

class _Contours:
    
    """A list of contours in a path.
    
    A specific contour in the list is drawn on the fly; 
    this way, the graphics state can be edited 
    before returning each contour (e.g. change of color, ...)
    
    """
    
    def __init__(self, path):
        
        self.path = path
        
        self.contours = []
        empty = True
        previous = 0
        
        for i in range(len(self.path)):
            if path[i].cmd == MOVETO:
                if not empty: self.contours.append(previous)
                empty = True
                previous = i
            elif path[i].cmd == LINETO or path[i].cmd == CURVETO:
                empty = False       
    
    def __getitem__(self, index):
        
        i = self.contours[index]
        _ctx.beginpath(self.path[i].x, self.path[i].y)
        
        for j in range(i+1, len(self.path)):
            
            if self.path[j].cmd == MOVETO:
                break
            elif self.path[j].cmd == LINETO:
                _ctx.lineto(self.path[j].x, self.path[j].y)
            elif self.path[j].cmd == CURVETO:
                _ctx.curveto(self.path[j].ctrl1.x,
                            self.path[j].ctrl1.y,
                            self.path[j].ctrl2.x,
                            self.path[j].ctrl2.y,
                            self.path[j].x,
                            self.path[j].y)
            elif self.path[j].cmd == CLOSE:
                _ctx.closepath()
                
        return _ctx.endpath(draw=False)

    def __iter__(self):
        
        for i in range(len(self)):
            yield self[i]

    def __len__(self):
        
        return len(self.contours)
    
def contours(path):
    
    """Returns a list of contours in the path.
    
    A contour is a sequence of lines and curves
    separated from the next contour by a MOVETO.
    
    For example, the glyph "o" has two contours:
    the inner circle and the outer circle.
    
    """
    
    return _Contours(path)
    
def findpath(points, curvature=1.0):
    
    """Constructs a path between the given list of points.
    
    Interpolates the list of points and determines
    a smooth bezier path betweem them.
    
    The curvature parameter offers some control on
    how separate segments are stitched together:
    from straight angles to smooth curves.
    Curvature is only useful if the path has more than  three points.
    
    """
    
    #The list of points consists of Point objects,
    #but it shouldn't crash on something straightforward
    #as someone supplying a list of (x,y)-tuples.
    
    from types import TupleType
    for i in range(len(points)):
        if type(points[i]) == TupleType:
            points[i] = Point(points[i][0], points[i][1])
    
    if len(points) == 0: return None
    if len(points) == 1:
        _ctx.beginpath(points[0].x, points[0].y)
        return _ctx.endpath(draw=False)
    if len(points) == 2:
        _ctx.beginpath(points[0].x, points[0].y)
        _ctx.lineto(points[1].x, points[1].y)
        return _ctx.endpath(draw=False)
              
    #Zero curvature means straight lines.
    
    curvature = max(0, min(1, curvature))
    if curvature == 0:
        _ctx.beginpath(points[0].x, points[0].y)
        for i in range(len(points)): 
            _ctx.lineto(points[i].x, points[i].y)
        return _ctx.endpath(draw=False)
        
    curvature = 4 + (1.0-curvature)*40
    
    dx = {0: 0, len(points)-1: 0}
    dy = {0: 0, len(points)-1: 0}
    bi = {1: -0.25}
    ax = {1: (points[2].x-points[0].x-dx[0]) / 4}
    ay = {1: (points[2].y-points[0].y-dy[0]) / 4}
    
    for i in range(2, len(points)-1):
        bi[i] = -1 / (curvature + bi[i-1])
        ax[i] = -(points[i+1].x-points[i-1].x-ax[i-1]) * bi[i]
        ay[i] = -(points[i+1].y-points[i-1].y-ay[i-1]) * bi[i]
        
    r = range(1, len(points)-1)
    r.reverse()
    for i in r:
        dx[i] = ax[i] + dx[i+1] * bi[i]
        dy[i] = ay[i] + dy[i+1] * bi[i]

    _ctx.beginpath(points[0].x, points[0].y)
    for i in range(len(points)-1):
        _ctx.curveto(points[i].x + dx[i], 
                     points[i].y + dy[i],
                     points[i+1].x - dx[i+1], 
                     points[i+1].y - dy[i+1],
                     points[i+1].x,
                     points[i+1].y)
    
    return _ctx.endpath(draw=False)

def split(path, t):
    
    """Returns a path copy with an extra point at t.
    """
    
    i, t, closeto = _locate(path, t)
    
    x0 = path[i].x
    y0 = path[i].y
    x3, y3, x1, y1, x2, y2 = _tuple(path[i+1])
    
    if path[i+1].cmd == CLOSE:
        point = _linepoint(t, x0, y0, closeto.x, closeto.y)
    if path[i+1].cmd == LINETO:
        point = _linepoint(t, x0, y0, x3, y3)        
    if path[i+1].cmd == CURVETO:
        point, ctrl1, ctrl2 = _curvepoint(t, x0, y0, x1, y1, x2, y2, x3, y3, handles=True)
    
    _ctx.beginpath(path[0].x, path[0].y)
    for j in range(1, len(path)):
        
        if j == i+1:
        
            if point.cmd == CURVETO:
                _ctx.curveto(ctrl1.x, ctrl1.y,
                             point.ctrl1.x, point.ctrl1.y,
                             point.x, point.y)
                _ctx.curveto(point.ctrl2.x, point.ctrl2.y,
                             ctrl2.x, ctrl2.y,
                             path[j].x, path[j].y)
                
                #_ctx.line(point.ctrl1.x, point.ctrl1.y, point.x, point.y)
                #_ctx.line(point.ctrl2.x, point.ctrl2.y, point.x, point.y)
                #_ctx.oval(point.x-2, point.y-2, 4, 4)
                
            elif point.cmd == LINETO:
                _ctx.lineto(point.x, point.y)
                _ctx.lineto(path[j].x, path[j].y)
            
        else:
           
            if path[j].cmd == MOVETO:
                _ctx.moveto(path[j].x, path[j].y)
            if path[j].cmd == LINETO:
                _ctx.lineto(path[j].x, path[j].y)
            if path[j].cmd == CURVETO:
                _ctx.curveto(path[j].ctrl1.x, path[j].ctrl1.y,
                             path[j].ctrl2.x, path[j].ctrl2.y,
                             path[j].x, path[j].y)
            if path[j].cmd == CLOSE:
                _ctx.closepath()               
   
    p = _ctx.endpath(draw=False)
    return p