speed(30)
size(400, 400)

coreimage = ximport("coreimage")

# This little object stores the position and size 
# of the current raindrop.
class Raindrop:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.r = 0

def setup():
    
    # Initialize a raindrop at a random location.
    global raindrops, max_raindrop_radius
    raindrops = []
    max_raindrop_radius = 300
    for i in range(2):
        raindrop = Raindrop(random(WIDTH), random(HEIGHT))
        raindrop.r = max_raindrop_radius/(i+1)
        raindrops.append(raindrop)

    
def draw():

    c = coreimage.canvas(WIDTH, HEIGHT)
    l = c.layer("nature.jpg")

    global raindrops, max_raindrop_radius
    for raindrop in raindrops:
        if raindrop.r > max_raindrop_radius:
            # If the raindrop is bigger than the maximum radius,
            # create a new raindrop at a new location.
            raindrop.x = random(WIDTH)
            raindrop.y = random(HEIGHT)
            raindrop.r = 0
        else:
            # If not, keep growing the raindrop.
            raindrop.r += 6
    
        # Punch a hole at the location of the raindrop.
        # As the radius of the raindrop grows bigger,
        # so does the hole.
        l = c.layer("nature.jpg")
        l.filter_holedistortion(dx = raindrop.x-WIDTH/2,
                                dy = raindrop.y-HEIGHT/2,
                                radius = raindrop.r)

        # The bigger the raindrop grows,
        # the more it fades out:
        # 1.0 means 100% opacity,
        # we subtract the percentage the current raindrop radius
        # is smaller than the maximum radius.
        l.blend(0.5 - 0.5*raindrop.r/max_raindrop_radius)
        #if raindrop.r == 0:
        #l.blend(50)
    
        # Using a sine wave is nicer because it eases in the motion.
        #from math import sin, radians
        #ease_in = sin(radians(90.0 * raindrop.r/max_raindrop_radius))
        #l.blend(1.0 - ease_in)
    
        # A nice touch of detail:
        # simultaneously using a hole and a bump
        # creates this ripple-kinda motion.
        l.filter_bumpdistortion(dx = raindrop.x-WIDTH/2,
                                dy = raindrop.y-HEIGHT/2,
                                radius = raindrop.r*2,
                                scale=-1.5)
    
        # A blur adds so more realism.    
        l.filter_blur(0.5)
    
    # Bluish hue layer.
    l = c.layer_fill(color(0,0.25,0.5))
    l.blend(50, "hue")
    
    c.draw()