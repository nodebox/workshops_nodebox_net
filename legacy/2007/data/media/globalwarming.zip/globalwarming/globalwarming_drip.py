size(400, 400)
speed(30)

coreimage = ximport("coreimage")

def setup():
    
    global cache
    cache = None
    
    global drip_x, drip_y
    drip_x = 100
    drip_y = 30

def draw():
    
    c = coreimage.canvas(WIDTH, HEIGHT)
    
    global cache
    #if cache == None:
    p = oval(0, 0, 47, 53, draw=False)
    cache = p
    cache = c.layer_path(cache)
    #else:
    #    cache = c.layer(cache)
    
    #global drip_x, drip_y
    
    #cache = cache.render()
    c.draw()