size(400, 400)
speed(30)

coreimage = ximport("coreimage")
reload(coreimage)
coreimage.PATH_PADDING = 10

def setup():
    
    global cache
    cache = None
    

def draw():
    
    c = coreimage.canvas(WIDTH, HEIGHT)

    fontsize(100)
    p = textpath("melt", 0, 0)
    l = c.layer_path(p)
    
    global cache
    if cache:
        cache = c.layer(cache)
    else:
        p = textpath("melt", 0, 0)
        cache = c.layer_path(p)
    
    #cache.filter_bumpdistortion(scale=-1.4, radius=30, 
    #                            dx=random(-100,300), 
    #                            dy=random(-20,10))
  
    #cache.filter_twirl(dx=random(-200,200),
    #                   dy=random(-50,100), 
    #                   angle=random(-500,400), 
    #                   radius=10)
    

    cache.blend(90)
    cache.scale(0.98,0.99)
    from math import sin
    cache.x += sin(FRAME)*1
    cache.y += 3
    cache.filter_twirl(angle=random(-100,100), radius=random(-50,50))
    #cache.filter_twirl(angle=100, radius=random(FRAME), dy=100)

    #cache.distort(dy2=1, dy3=1,dx3=random(5),dx2=random(-5))

    #cache.filter_bumpdistortion(scale=-1.4, radius=30, 
    #                            dx=random(-100,300), 
    #                            dy=random(-20,100))

    cache = c.render()
    
    cache = c.layer(cache)
    cache.scale(0.8,1.05)
    cache.blend(10)
    cache.y += 10
    cache.x += random(-50,50)
    #cache.rotate(random(-15,15))
    
    cache = c.render()
    
    
    c.draw()