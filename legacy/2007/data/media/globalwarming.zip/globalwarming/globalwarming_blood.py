x = 29
y = 100

font("ArialRoundedMTBold", 100)
p = textpath("hello", x, y)

from AppKit import NSRoundLineJoinStyle
p.path.setLineJoinStyle_(NSRoundLineJoinStyle)

stroke(0)

translate(50, 100)

pts = []
for pt in p:
    if pt.cmd == CURVETO and pt.y > y-fontsize()/3:
        pt.ctrl1.y *= 1.2
        strokewidth(1)
        
        beginpath(pt.x, pt.y)
        curveto(pt.x-5, pt.y, pt.x+5, pt.y, pt.x, pt.y+random(200))
        endpath()
    pts.append(pt)

strokewidth(5)
drawpath(pts)