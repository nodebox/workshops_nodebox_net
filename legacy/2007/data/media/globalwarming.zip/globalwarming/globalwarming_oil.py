size(400, 400)
speed(30)

coreimage = ximport("coreimage")
reload(coreimage)
coreimage.PATH_PADDING = 10

def setup():
    
    global cache
    cache = None
    

def draw():
    
    c = coreimage.canvas(WIDTH, HEIGHT)

    fontsize(100)
    p = textpath("hello", 0, 0)
    l = c.layer_path(p)
    
    global cache
    if cache:
        cache = c.layer(cache)
    else:
        p = textpath("hello", 0, 0)
        cache = c.layer_path(p)
    
    cache.filter_bumpdistortion(scale=-3.4, radius=30, 
                                dx=random(-100,300), 
                                dy=random(-20,10))
  
    cache.filter_twirl(dx=random(-200,200),
                       dy=random(-50,100), 
                       angle=random(-200,400), 
                       radius=100)
    
    cache = c.render()
    c.draw()