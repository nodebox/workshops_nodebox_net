number_list = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0]


def clamp(x, min, max):
    if x < min:
        return min
    elif x > max:
        return max
    return x
    
def influence(n1, n2, factor):
    return (n1 + n2 * factor) / (1+factor)
    
def influence_delta(n1, n2, factor):
    """Returns the delta of the influence"""
    return 0
    
def average_out(list, factor=0.5):
    new_list = []
    list_size = len(number_list) - 1
    for i, n in enumerate(number_list):
        prev = number_list[clamp(i-1, 0, list_size)]
        next = number_list[clamp(i+1, 0, list_size)]
        print "number at pos", i, ":", n,"prev", prev, "i",  influence(n, prev, factor), "next", next, "i", influence(n, next, factor)
        n = (influence(n, prev, factor) + influence(n, next, factor)) / 2.0
        new_list.append(n)    
    return new_list    


def find_avg(n, list, factor=0.5):
    avg = n
    i = 0
    while factor > 0.0 and i < len(list):
        avg = influence(avg, list[i], min(factor, 1.0))
        factor -= 1.0
        i += 1
    return avg
    
print find_avg(0.0, number_list, 2.09)

#print average_out(number_list, 0.05)
    