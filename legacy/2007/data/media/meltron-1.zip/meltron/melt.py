from math import pi, sqrt, sin, cos, asin, atan2

def calc_dist(x1, y1, x2, y2):
    return atan2(x2-x1, y2-y1)


def path_from_points(pts):
    assert len(pts) > 1
    path = BezierPath()
    path.moveto(pts[0].x, pts[0].y)
    for pt in pts[1:]:
        if isinstance(pt, PathElement) and pt.cmd == CURVETO:
            path.curveto(pt.ctrl1.x, pt.ctrl1.y, pt.ctrl2.x, pt.ctrl2.y, pt.x, pt.y)
        elif isinstance(pt, PathElement) and pt.cmd == MOVETO:
            path.moveto(pt.x, pt.y)
        elif isinstance(pt, PathElement) and pt.cmd == CLOSE:
            path.closepath()
        else:
            path.lineto(pt.x, pt.y)    
    path.inheritFromContext()
    return path

txt = "mult"

font("Times", 242)
path = textpath(txt, 100, 214)

nofill()
stroke(0)
fill(0)

d = 0.82
d2 = 0.55
d3 = 0.01

nofill()
stroke(0)
o = oval(453, -4, 100, 100)
(ox, oy), (ow, oh) = o.bounds
ocx = ox + ow/2.0
ocy = oy + oh/2.0


for contour in path.contours:
    point_list = []
    
    
    #for pt in contour:
    #    if pt.y < 138:
    #        pt.y *= d
    #        pt.ctrl1.y *= d2
    #        pt.ctrl2.y *= d2
    #    point_list.append(pt)
    
    points = list(contour.points(200))
    for i, pt in enumerate(points):

        dist = abs(calc_dist(ocx, ocy, pt.x, pt.y))
        pt.y += pow(dist, 4.13)
        #pt.x += dist * 2.0
        #print 1.0 / dist

#        if o.contains(pt.x, pt.y):
#            pt.y += (500 - pt.y) * 0.05
        point_list.append(pt)


#        if pt.y < 138:
#            pt.y *= d
#            pt.ctrl1.y *= d2
#            pt.ctrl2.y *= d2
#            
#        if pt.y > 148:
#            if i > 0 and points[i-1].x > pt.x:
#                new_pt = Point(pt.x + pt.x*d3, pt.y)
#                #pt.x -= pt.x*d3
#            else:
#                new_pt = Point(pt.x - pt.x*d3, pt.y)
#                #pt.x += pt.x*d3
#        else:
#            new_pt = Point(pt.x, pt.y)
#        point_list.append(new_pt)        

    #contour.draw()
    fill(0)
    nostroke()
    new_path = path_from_points(point_list)
    new_path.closepath()
    new_path.draw()